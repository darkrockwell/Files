<?php

date_default_timezone_set('Asia/Manila');

if(!isset($_SESSION)) 
{ 
	session_start(); 
} 

$usr = 'u685655802_horizoneapp';
$pss = '3P42e7ytp8l4!';

try {
	$connection = new PDO( 'mysql:host=localhost;dbname=u685655802_horizoneappdb', $usr, $pss );
}
catch(Exception $e) {
	die('Error :'.$e->getMessage());
}

if(isset($_SESSION['user_session'])){
	$stmt = $connection->prepare("SELECT e.*, p.* FROM employees e INNER JOIN positions p ON p.id = e.position_id WHERE e.id = :id");
    $stmt->bindParam(':id', $_SESSION['user_session']);
    $stmt->execute();
    $user = $stmt->fetch();
}


function audit($connection, $action){

	$stmt = $connection->prepare("INSERT INTO audits(user_id, action) VALUES(:uid, :action)");
	$stmt->bindParam(':uid', $_SESSION['user_session']);
	$stmt->bindParam(':action', $action);
	$stmt->execute();

}

?>