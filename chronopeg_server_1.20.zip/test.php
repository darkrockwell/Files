<?php

echo "Your Horizone Tool Server is working!";

?>