<?php

header('Location: test.php');

?>
