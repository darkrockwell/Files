<?php 

require_once '../db.php';

header("Content-Type: text/plain");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: X-Requested-With");

date_default_timezone_set('Asia/Manila');
//echo date('Y-m-d H:i:s');

//$arr['msgs'] = $_POST['test'];
//echo json_encode($arr);

$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $gen_log_tkn = generate_string($permitted_chars, 70);
    $datetime = date('Y-m-d H:i:s');
    
    $days = [
      0 => 'Sun',
      1 => 'Mon',
      2 => 'Tue',
      3 => 'Wed',
      4 => 'Thu',
      5 => 'Fri',
      6 => 'Sat'
    ];
    
    if(isset($_POST['action']) == 'lgn_usr'){
        
        $h_t_unme = trim(filter_var($_POST['h_t_unme'], FILTER_SANITIZE_STRING));
        $h_t_pswrd = trim(filter_var($_POST['h_t_pswrd'], FILTER_SANITIZE_STRING));
        
        function checkUserLogin($h_t_unme, $h_t_pswrd, $connection){

            $chk0 = $connection->prepare("SELECT * FROM team_managers WHERE username = :tname AND password = :tpass");
            $chk0->bindParam(':tname', $h_t_unme);
            $chk0->bindParam(':tpass', $h_t_pswrd);
            if($chk0->execute()){
                $chkrow0 = $chk0->fetch();
                if(!empty($chkrow0['username']) && !empty($chkrow0['password'])){
                    return 'TM Login';
                }
            }

            $chk1 = $connection->prepare("SELECT * FROM reviewers WHERE username = :uname AND password = :pass");
            $chk1->bindParam(':uname', $h_t_unme);
            $chk1->bindParam(':pass', $h_t_pswrd);
            if($chk1->execute()){
                $chkrow1 = $chk1->fetch();
                if(!empty($chkrow1['username']) && !empty($chkrow1['password'])){
                    return 'Reviewer Login';
                }
            }

        }
        
        if(checkUserLogin($h_t_unme, $h_t_pswrd, $connection) == 'Reviewer Login'){
            $stmt0 = $connection->prepare("SELECT * FROM reviewers WHERE username = :uname AND password = :pass");
     		$stmt0->bindParam(':uname', $h_t_unme);
     		$stmt0->bindParam(':pass', $h_t_pswrd);
     		
     		if($stmt0->execute()){
     		    
     		    $row0 = $stmt0->fetch();
     		    
     		    if(!empty($row0['username']) && !empty($row0['password'])){
                    
                    $doff = $row0['dayoff'];
                    $doff_arr = explode(',', $doff);
     		        
         		    $status = "In production";
        
         			audit($connection, 'Reviewer Login');
                    $arr['loginMsg'] = 'Reviewer Login Success!';
                    
                    $arr['h_t_revid'] = $row0['reviewer_id'];
                    $arr['h_t_unme'] = $row0['username'];
                    $arr['h_t_pswrd'] = $row0['password'];
                    $arr['h_t_nme'] = $row0['firstname'] .' '. $row0['lastname'];
                    $arr['h_t_rle'] = 'Reviewer';
                    $arr['h_t_doffs'] = $days[date($doff_arr[0])] .' - '. $days[date($doff_arr[1])];
                    $arr['lg_token'] = $gen_log_tkn;
                    $arr['lg_pos'] = 'romeo';
                    
                    $stmt0 = $connection->prepare("UPDATE reviewers SET status = :sts, login_token = :tkn, updated_at = :uat WHERE reviewer_id = :rid");
                    $stmt0->bindParam(':sts', $status);
                    $stmt0->bindParam(':tkn', $gen_log_tkn);
                    $stmt0->bindParam(':rid', $row0['reviewer_id']);
                    $stmt0->bindParam(':uat', $datetime);
                    if($stmt0->execute()){
                        $arr['loginUpdateToken'] = "Reviewer Status Update Success!!";
                    }
                    else {
                        $arr['loginUpdateToken'] = "Reviewer Status Update Failed!!";
                    }
                    
         		}
         		else {
         			$arr['loginMsg'] = 'Reviewer Login Failed!';
         		}
     		}
     		else {
     		    $arr['loginDebugger'] = 'Reviewer Execute failed!';
     		}
        }
        else {
            $arr['loginRevMsg'] = 'Reviewer Auth Failed!';
        }
        
        if(checkUserLogin($h_t_unme, $h_t_pswrd, $connection) == 'TM Login'){
            

            $stmt0 = $connection->prepare("SELECT * FROM team_managers WHERE username = :uname AND password = :pass");
     		$stmt0->bindParam(':uname', $h_t_unme);
     		$stmt0->bindParam(':pass', $h_t_pswrd);
     		
     		if($stmt0->execute()){
     		    
     		    $row0 = $stmt0->fetch();
     		    
     		    $stmt1 = $connection->prepare("SELECT reviewer_id FROM reviewers WHERE tm_id = :tid ORDER BY firstname ASC");
     		    $stmt1->bindParam(':tid', $row0['tm_id']);
     		    if($stmt1->execute()){
     		        $row1 = $stmt1->fetchAll();
     		        $arr['rev_ids'] = $row1;
     		    }
     		    
     		    if(!empty($row0['username']) && !empty($row0['password'])){
     		        
     		        $doff = $row0['dayoff'];
                    $doff_arr = explode(',', $doff);
     		        
         		    $status = "In production";
        
         			audit($connection, 'TM Login');
                    $arr['loginMsg'] = 'TM Login Success!';
                    
                    $arr['h_t_revid'] = $row0['tm_id'];
                    $arr['h_t_unme'] = $row0['username'];
                    $arr['h_t_pswrd'] = $row0['password'];
                    $arr['h_t_nme'] = $row0['firstname'] .' '. $row0['lastname'];
                    $arr['h_t_rle'] = 'Team Manager';
                    $arr['h_t_doffs'] = $days[date($doff_arr[0])] .' - '. $days[date($doff_arr[1])];
                    $arr['lg_token'] = $gen_log_tkn;
                    $arr['lg_pos'] = 'tango';
                    
                    $stmt0 = $connection->prepare("UPDATE team_managers SET status = :sts, login_token = :tkn, updated_at = :uat WHERE tm_id = :tid");
                    $stmt0->bindParam(':sts', $status);
                    $stmt0->bindParam(':tkn', $gen_log_tkn);
                    $stmt0->bindParam(':tid', $row0['tm_id']);
                    $stmt0->bindParam(':uat', $datetime);
                    if($stmt0->execute()){
                        $arr['loginUpdateToken'] = "TM Status Update Success!!";
                    }
                    else {
                        $arr['loginUpdateToken'] = "TM Status Update Failed!!";
                    }
                    
         		}
         		else {
         			$arr['loginMsg'] = 'TM Login Failed!';
         		}
     		}
     		else {
     		    $arr['loginDebugger'] = 'TM Execute failed!';
     		}
        }
        else {
            $arr['loginTmMsg'] = 'TM Auth Failed!';
        }
    
    }
    
    
    
    if(isset($_POST['action_c']) == 'check_lg_token'){
        
        $c_lg_token = isset($_POST['c_lg_token']);
        $c_lg_pos = isset($_POST['c_lg_pos']);
        
        if(isset($_POST['c_lg_token'])){
            $c_lg_token = trim(filter_var($_POST['c_lg_token'], FILTER_SANITIZE_STRING));
        }
        
        if(isset($_POST['c_lg_pos'])){
            $c_lg_pos = trim(filter_var($_POST['c_lg_pos'], FILTER_SANITIZE_STRING));
        }
        
        if($c_lg_pos == 'tango'){
            $stmt = $connection->prepare("SELECT * FROM team_managers WHERE login_token = :tkn");
     		$stmt->bindParam(':tkn', $c_lg_token);
    
     		if($stmt->execute()){
     		    
     		    $row = $stmt->fetch();
     		    
     		    if(!empty($row['login_token'])){
    
                    $arr['authMsg'] = 'TM Token Success!';
                    
         		}
         		else {
         			$arr['authMsg'] = 'TM Token Failed!';
         		}
     		}
        }
        else if($c_lg_pos == 'romeo'){
            $stmt = $connection->prepare("SELECT * FROM reviewers WHERE login_token = :tkn");
     		$stmt->bindParam(':tkn', $c_lg_token);
    
     		if($stmt->execute()){
     		    
     		    $row = $stmt->fetch();
     		    
     		    if(!empty($row['login_token'])){
    
                    $arr['authMsg'] = 'Reviewer Token Success!';
                    
         		}
         		else {
         			$arr['authMsg'] = 'Reviewer Token Failed!';
         		}
     		}
        }
        else {
            $arr['authMsg'] = 'Pos Empty';
        }
    	
    	
    }
    
    echo json_encode($arr);
    
}


?>