<?php 

require_once '../db.php';

header("Content-Type: text/plain");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: X-Requested-With");

date_default_timezone_set('Asia/Manila');
//echo date('Y-m-d H:i:s');

function getWorkingDays($start_d, $end_d, $off1, $off2){
    
    $n_start_d = date("Y-m-d", strtotime($start_d));
    $n_end_d = date("Y-m-d", strtotime($end_d));
    
$start = new DateTime($n_start_d);
$end = new DateTime($n_end_d);
// otherwise the  end date is excluded (bug?)
$end->modify('+1 day');

$interval = $end->diff($start);

// total days
$days = $interval->days;

// create an iterateable period of date (P1D equates to 1 day)
$period = new DatePeriod($start, new DateInterval('P1D'), $end);

// best stored as array, so you can add more than one
$holidays = array();

foreach($period as $dt) {
    $curr = $dt->format('w');

    // substract if Saturday or Sunday
    if ($curr == $off1 || $curr == $off2) {
        $days--;
    }

    // (optional) for the updated question
    elseif (in_array($dt->format('Y-m-d'), $holidays)) {
        $days--;
    }
}


return $days;

}

function convertMinute($min){
	$min = ($min == 1 || $min == 0) ? $min . ' min' : $min . ' mins';
	return $min;
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $datetime = date('Y-m-d H:i:s');
    
    if(isset($_POST['action']) == 'Save Chrono Peg') {

        $reviewer_id = trim(filter_var($_POST['reviewer_id'], FILTER_SANITIZE_STRING));     
        $selected_peg = trim(filter_var($_POST['selected_peg'], FILTER_SANITIZE_STRING)); 
        $time_consumed = trim(filter_var($_POST['time_consumed'], FILTER_SANITIZE_STRING));
        
        $t_manager_id;
        
        $stmt0 = $connection->prepare("SELECT t.tm_id, t.lastname, t.firstname, r.reviewer_id, r.tm_id, r.lastname, r.firstname FROM reviewers r
        INNER JOIN team_managers t
        ON r.tm_id = t.tm_id
        WHERE r.reviewer_id = :rid
        AND r._delete = 0
        AND t._delete = 0");
        $stmt0->bindParam(':rid', $reviewer_id);
        if($stmt0->execute()){
            $row0 = $stmt0->fetch();
            
            $t_manager_id = $row0['tm_id'];
            
            $arr['chk_tm_msg'] = 'Success!';
        }
        else {
            $arr['chk_tm_msg'] = 'Failed!';
        }
        
        
        $stmt = $connection->prepare("INSERT INTO chronopeg (reviewer_id, tm_id, peg_name, time_consumed, created_at, updated_at) VALUE(:rid, :tid, :pname, :tcons, :ca, :ua)");
        $stmt->bindParam(':rid', $reviewer_id);
        $stmt->bindParam(':tid', $t_manager_id);
        $stmt->bindParam(':pname', $selected_peg);
        $stmt->bindParam(':tcons', $time_consumed);
        $stmt->bindParam(':ca', $datetime);
        $stmt->bindParam(':ua', $datetime);
        if($stmt->execute()){
            
             $arr['time_consumed'] = $time_consumed;
             $arr['exec_message'] = 'Success!';
        }
        else {
            $arr['exec_message'] = 'Failed!';
        }
        
        echo json_encode($arr);
    }
    
    if(isset($_POST['getChronoPegs']) == 'Get Chrono Pegs') {
        
        $user_id = trim(filter_var($_POST['user_id'], FILTER_SANITIZE_STRING));
        $lg_pos = trim(filter_var($_POST['lg_pos'], FILTER_SANITIZE_STRING));
        $start_date = trim(filter_var($_POST['start_date'], FILTER_SANITIZE_STRING));
        $end_date = trim(filter_var($_POST['end_date'], FILTER_SANITIZE_STRING));
        
        $tc_training = 0;
        $tc_coaching = 0;
        $tc_huddle = 0;
        $tc_meeting = 0;
        $tc_wellness = 0;
        
        $wooffs;
        
        // $myString = "9,admin@example.com,8";
        // $myArray = explode(',', $myString);
        
        // $datetime1 = new DateTime('2020-09-01');
        // $datetime2 = new DateTime('2020-09-30');
        // $interval = $datetime1->diff($datetime2);
        // $woweekends = 0;
        // for($i=0; $i<=$interval->d; $i++){
        //     $datetime1->modify('+1 day');
        //     $weekday = $datetime1->format('w');
        
        //     if($weekday !== "5" && $weekday !== "6"){ // 0 for Sunday and 6 for Saturday
        //         $woweekends++;  
        //     }
        
        // }
        
        // echo $woweekends." days without weekend";
        
        if($lg_pos == 'romeo'){
            
            $stmt0 = $connection->prepare("SELECT * FROM reviewers WHERE reviewer_id = :rid");
            $stmt0->bindParam(':rid', $user_id);
            if($stmt0->execute()){
                $row0 = $stmt0->fetch();
                $dayoff = $row0['dayoff'];
                $dayoffarr = explode(',', $dayoff);
                
                $wooffs = getWorkingDays($start_date, $end_date, $dayoffarr[0], $dayoffarr[1]);
                
            }
            
            $stmt = $connection->prepare("SELECT r.reviewer_id, r.lastname, r.firstname, c.chronopeg_id, c.reviewer_id, c.peg_name, c.time_consumed, c._delete, c.created_at FROM chronopeg c
            INNER JOIN reviewers r
            ON c.reviewer_id = r.reviewer_id
            WHERE c.created_at
            BETWEEN :sdate
            AND :edate
            AND c.reviewer_id = :rid
            AND c._delete = 0
            ORDER BY c.chronopeg_id DESC");
            $stmt->bindParam(':sdate', $start_date);
            $stmt->bindParam(':edate', $end_date);
            $stmt->bindParam(':rid', $user_id);
            $stmt->execute();
            //$result = $stmt->fetchAll();
            //$data = array();
            
            while($row = $stmt->fetch()){
                if($row['peg_name'] == 'FB training'){
                    $tc_training += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'Coaching'){
                    $tc_coaching += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'In a huddle'){
                    $tc_huddle += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'Team meeting'){
                    $tc_meeting += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'At wellness support'){
                    $tc_wellness += $row['time_consumed'];
                }
            }
            
            $training_max = floor(0.30 * $wooffs * 60);
    		$coaching_max = floor(0.25 * $wooffs *60);
    		$huddle_max = floor(0.25 * $wooffs * 60);
    		$meeting_max = floor(0.15 * $wooffs * 60);
    		$wellness_max = floor(0.15 * $wooffs * 60);
    		
    		$res['wooffs'] = $wooffs;
            
            $res['pegTraining'] = $tc_training;
            $res['pegCoaching'] = $tc_coaching;
            $res['pegHuddle'] = $tc_huddle;
            $res['pegMeeting'] = $tc_meeting;
            $res['pegWellness'] = $tc_wellness;
            
            $res['diffTraining'] = $training_max - $tc_training;
            $res['diffCoaching'] = $coaching_max - $tc_coaching;
            $res['diffHuddle'] = $huddle_max - $tc_huddle;
            $res['diffMeeting'] = $meeting_max - $tc_meeting;
            $res['diffWellness'] = $wellness_max - $tc_wellness;
        }
        else  if($lg_pos == 'tango'){
            
            $rev_count;
            
            $stmt0 = $connection->prepare("SELECT * FROM team_managers WHERE tm_id = :tid");
            $stmt0->bindParam(':tid', $user_id);
            if($stmt0->execute()){
                $row0 = $stmt0->fetch();
                $dayoff = $row0['dayoff'];
                $dayoffarr = explode(',', $dayoff);
                
                $wooffs = getWorkingDays($start_date, $end_date, $dayoffarr[0], $dayoffarr[1]);
                
            }
            
            $stmt1 = $connection->prepare("SELECT * FROM team_managers t
            INNER JOIN reviewers r
            ON t.tm_id = r.tm_id
            WHERE t.tm_id = :tid
            AND t._delete = 0
            AND r._delete = 0");
            $stmt1->bindParam(':tid', $user_id);
            if($stmt1->execute()){
                
                $rev_count = $stmt1->rowCount();
                
            }
            
            $stmt = $connection->prepare("SELECT t.tm_id, t.lastname, t.firstname, c.chronopeg_id, c.tm_id, c.peg_name, c.time_consumed, c._delete, c.created_at FROM chronopeg c
            INNER JOIN team_managers t
            ON c.tm_id = t.tm_id
            WHERE c.created_at
            BETWEEN :sdate
            AND :edate
            AND c.tm_id = :tid
            AND c._delete = 0
            ORDER BY c.chronopeg_id DESC");
            $stmt->bindParam(':sdate', $start_date);
            $stmt->bindParam(':edate', $end_date);
            $stmt->bindParam(':tid', $user_id);
            $stmt->execute();
            //$result = $stmt->fetchAll();
            //$data = array();
            
            while($row = $stmt->fetch()){
                if($row['peg_name'] == 'FB training'){
                    $tc_training += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'Coaching'){
                    $tc_coaching += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'In a huddle'){
                    $tc_huddle += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'Team meeting'){
                    $tc_meeting += $row['time_consumed'];
                }
                else if($row['peg_name'] == 'At wellness support'){
                    $tc_wellness += $row['time_consumed'];
                }
            }
            
            $training_max = floor(0.30 * $wooffs * 60 * $rev_count);
    		$coaching_max = floor(0.25 * $wooffs *60 * $rev_count);
    		$huddle_max = floor(0.25 * $wooffs * 60 * $rev_count);
    		$meeting_max = floor(0.15 * $wooffs * 60 * $rev_count);
    		$wellness_max = floor(0.15 * $wooffs * 60 * $rev_count);
    		
    		$res['wooffs'] = $wooffs;
    		$res['rev_count'] = $rev_count;
            
            $res['pegTraining'] = $tc_training;
            $res['pegCoaching'] = $tc_coaching;
            $res['pegHuddle'] = $tc_huddle;
            $res['pegMeeting'] = $tc_meeting;
            $res['pegWellness'] = $tc_wellness;
            
            $res['diffTraining'] = $training_max - $tc_training;
            $res['diffCoaching'] = $coaching_max - $tc_coaching;
            $res['diffHuddle'] = $huddle_max - $tc_huddle;
            $res['diffMeeting'] = $meeting_max - $tc_meeting;
            $res['diffWellness'] = $wellness_max - $tc_wellness;
        }
        
        echo json_encode($res);
        
    }
    
    
    if(isset($_POST['getChronoReport']) == 'Get Chronopeg Report') {
        
        $user_id = trim(filter_var($_POST['user_id'], FILTER_SANITIZE_STRING));
        $lg_pos = trim(filter_var($_POST['lg_pos'], FILTER_SANITIZE_STRING));
        
        $column = array('chronopeg_id', 'peg_name', 'time_consumed', 'created_at');
        
        if($lg_pos == 'romeo'){
            $query = "SELECT r.reviewer_id as rid, r.lastname as rlname, r.firstname as rfname, c.chronopeg_id as cid, c.reviewer_id, c.peg_name, c.time_consumed, c._delete, c.created_at as cca FROM chronopeg c
            INNER JOIN reviewers r
            ON c.reviewer_id = r.reviewer_id
            AND c.reviewer_id = '".$user_id."' ";
        }
        else if($lg_pos == 'tango'){
            // $query = "SELECT r.reviewer_id, r.lastname, r.firstname, c.chronopeg_id as cid, c.reviewer_id, c.peg_name, c.time_consumed, c._delete, c.created_at as cca FROM chronopeg c
            // INNER JOIN reviewers r
            // ON c.reviewer_id = r.reviewer_id
            // AND c.reviewer_id = '".$user_id."' ";
            
            $query = "SELECT t.tm_id as tid, t.lastname, t.firstname, r.reviewer_id, r.lastname as rlname, r.firstname as rfname, c.chronopeg_id as cid, c.reviewer_id, c.peg_name, c.time_consumed, c._delete, c.created_at as cca FROM chronopeg c
            INNER JOIN team_managers t
            ON c.tm_id = t.tm_id
            INNER JOIN reviewers r
            ON c.reviewer_id = r.reviewer_id
            AND c.tm_id = '".$user_id."' ";
        }

        
        
        if(isset($_POST['start_date'], $_POST['end_date']) && $_POST['start_date'] != '' && $_POST['end_date'] != '')
        {
         $query .= 'WHERE c.created_at BETWEEN "'.$_POST['start_date'].'" AND "'.$_POST['end_date'].'" ';
        }
        
        if(isset($_POST['order']))
        {
         $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
        }
        else
        {
         $query .= 'ORDER BY c.chronopeg_id DESC ';
        }
        
        $query1 = '';
        
        if($_POST["length"] != -1)
        {
         $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
        }
        
        $statement = $connection->prepare($query);
        
        $statement->execute();
        
        $number_filter_row = $statement->rowCount();
        
        $statement = $connection->prepare($query . $query1);
        
        $statement->execute();
        
        $result = $statement->fetchAll();
        
        $data = array();
        $num = 0;
        foreach($result as $row)
        {
        
         $num++;
         $sub_array = array();
         $sub_array[] = ($lg_pos == 'tango') ? $row['rfname'] .' '. $row['rlname'] : 'CH-' . $row['cid'];
         $sub_array[] = $row['peg_name'];
         $sub_array[] = convertMinute($row['time_consumed']);
         $sub_array[] = $row['cca'];
         $sub_array[] = ($lg_pos == 'tango') ? '<button type="button" id="'.$row['cid'].'" class="btn btn-warning btn-sm" tooltip="Edit" flow="up"><i class="fas fa-pen"></i></button> <button type="button" id="'.$row['cid'].'" class="btn btn-danger btn-sm" tooltip="Delete" flow="up"><i class="fas fa-trash"></i></button>' : '<button type="button" id="'.$row['cid'].'" class="btn btn-warning btn-sm rev-file-dspt" tooltip="File dispute" flow="up"><i class="fas fa-pen"></i></button>';
         $data[] = $sub_array;
        }
        
        function count_all_data($connection, $lg_pos, $user_id){
            
            if($lg_pos == 'romeo'){
                $query = "SELECT * FROM chronopeg WHERE reviewer_id = :rid AND _delete = 0";
                $statement = $connection->prepare($query);
                $statement->bindParam(':rid', $user_id);
            }
            else if($lg_pos == 'tango'){
                $query = "SELECT * FROM chronopeg WHERE tm_id = :tid AND _delete = 0";
                $statement = $connection->prepare($query);
                $statement->bindParam(':tid', $user_id);
            }
            
            $statement->execute();
            return $statement->rowCount();
        }
        
        $output = array(
         "draw"             =>  intval($_POST["draw"]),
         "recordsTotal"     =>  count_all_data($connection, $lg_pos, $user_id),
         "recordsFiltered"  =>  $number_filter_row,
         "data"             =>  $data
        );
        
        echo json_encode($output);
    }
    
    function getItemsPerReviewer($connection, $user_id, $start_date, $end_date){
        
        $tc_training = 0;
        $tc_coaching = 0;
        $tc_huddle = 0;
        $tc_meeting = 0;
        $tc_wellness = 0;
        
        $wooffs;
        $rev_name;
        
        $stmt0 = $connection->prepare("SELECT * FROM reviewers WHERE reviewer_id = :rid ORDER BY firstname ASC");
        $stmt0->bindParam(':rid', $user_id);
        if($stmt0->execute()){
            $row0 = $stmt0->fetch();
            $dayoff = $row0['dayoff'];
            $dayoffarr = explode(',', $dayoff);
            $rev_name = $row0['firstname'] .' '. $row0['lastname'];
            $wooffs = getWorkingDays($start_date, $end_date, $dayoffarr[0], $dayoffarr[1]);
            
        }
        
        $stmt = $connection->prepare("SELECT r.reviewer_id, r.lastname, r.firstname, c.chronopeg_id, c.reviewer_id, c.peg_name, c.time_consumed, c._delete, c.created_at FROM chronopeg c
        INNER JOIN reviewers r
        ON c.reviewer_id = r.reviewer_id
        WHERE c.created_at
        BETWEEN :sdate
        AND :edate
        AND c.reviewer_id = :rid
        AND c._delete = 0
        ORDER BY c.chronopeg_id DESC");
        $stmt->bindParam(':sdate', $start_date);
        $stmt->bindParam(':edate', $end_date);
        $stmt->bindParam(':rid', $user_id);
        $stmt->execute();
        //$result = $stmt->fetchAll();
        //$data = array();
        
        while($row = $stmt->fetch()){
            if($row['peg_name'] == 'FB training'){
                $tc_training += $row['time_consumed'];
            }
            else if($row['peg_name'] == 'Coaching'){
                $tc_coaching += $row['time_consumed'];
            }
            else if($row['peg_name'] == 'In a huddle'){
                $tc_huddle += $row['time_consumed'];
            }
            else if($row['peg_name'] == 'Team meeting'){
                $tc_meeting += $row['time_consumed'];
            }
            else if($row['peg_name'] == 'At wellness support'){
                $tc_wellness += $row['time_consumed'];
            }
        }
        
        $training_max = floor(0.30 * $wooffs * 60);
		$coaching_max = floor(0.25 * $wooffs *60);
		$huddle_max = floor(0.25 * $wooffs * 60);
		$meeting_max = floor(0.15 * $wooffs * 60);
		$wellness_max = floor(0.15 * $wooffs * 60);
		
		$res['rev_name'] = $rev_name;
		$res['wooffs'] = $wooffs;
        
        $res['pegTraining'] = $tc_training;
        $res['pegCoaching'] = $tc_coaching;
        $res['pegHuddle'] = $tc_huddle;
        $res['pegMeeting'] = $tc_meeting;
        $res['pegWellness'] = $tc_wellness;
        
        $res['diffTraining'] = $training_max - $tc_training;
        $res['diffCoaching'] = $coaching_max - $tc_coaching;
        $res['diffHuddle'] = $huddle_max - $tc_huddle;
        $res['diffMeeting'] = $meeting_max - $tc_meeting;
        $res['diffWellness'] = $wellness_max - $tc_wellness;
        
        echo json_encode($res);
    }    
    
    if(isset($_POST['getChronoPegsPerRevs']) == 'Get Items Per Reviewer') {
        
        $user_id = trim(filter_var($_POST['user_id'], FILTER_SANITIZE_STRING));
        $lg_pos = trim(filter_var($_POST['lg_pos'], FILTER_SANITIZE_STRING));
        $start_date = trim(filter_var($_POST['start_date'], FILTER_SANITIZE_STRING));
        $end_date = trim(filter_var($_POST['end_date'], FILTER_SANITIZE_STRING));
        
        $revs = $_POST['revs'];
        
        //$arr = array(1, 6);
        
        
        if($lg_pos == 'tango'){
            
            getItemsPerReviewer($connection, $revs, $start_date, $end_date);
            
            // foreach($revs as $rev){
            //     //echo $row . '<br>';
                
            //     getItemsPerReviewer($connection, $rev, $start_date, $end_date);
            // }
            
            // for($i = 0; i <= count($revs); ){
                
            // }
            
            //echo count($revs);
            
        }
    }
    
    if(isset($_POST['action_dspt']) == 'View Chronopeg Dispute'){
        
       $ch_peg_id = trim(filter_var($_POST['ch_peg_id'], FILTER_SANITIZE_STRING));
       
       $stmt = $connection->prepare("SELECT * FROM chronopeg WHERE chronopeg_id = :cid");
       $stmt->bindParam(':cid', $ch_peg_id);
       if($stmt->execute()){
           
           $row = $stmt->fetch();
           
           if($stmt->rowCount() > 0){
               
               $arr['cid'] = $row['chronopeg_id'];
               $arr['peg_name'] = $row['peg_name'];
               $arr['time_consumed'] = convertMinute($row['time_consumed']);
               $arr['exec_mesg'] = 'Success!';
              
           }
           else {
               $arr['exec_mesg'] = 'Failed!';
           }
           
            echo json_encode($arr);
           
       }
       
    }
    
    if(isset($_POST['action_sbmt_dspt']) == 'Submit Reviewer Dispute'){
        
       $reviewer_id = trim(filter_var($_POST['reviewer_id'], FILTER_SANITIZE_STRING));
       $ch_peg_id = trim(filter_var($_POST['ch_peg_id'], FILTER_SANITIZE_STRING));
       $ch_ctc = trim(filter_var($_POST['ch_ctc'], FILTER_SANITIZE_STRING));
       $ch_dspt_remarks = trim(filter_var($_POST['ch_dspt_remarks'], FILTER_SANITIZE_STRING));
       
       $stmt = $connection->prepare("INSERT INTO dispute (chronopeg_id, reviewer_id, correct_tc, remarks, created_at, updated_at) VALUES(:chid, :rid, :ctc, :rem, :ca, :ua)");
       $stmt->bindParam(':chid', $ch_peg_id);
       $stmt->bindParam(':rid', $reviewer_id);
       $stmt->bindParam(':ctc', $ch_ctc);
       $stmt->bindParam(':rem', $ch_dspt_remarks);
       $stmt->bindParam(':ca', $datetime);
       $stmt->bindParam(':ua', $datetime);
       if($stmt->execute()){
           $msg['exec_msg'] = 'Success!';
       }
       else {
           $msg['exec_msg'] = 'Failed!';
       }
       echo json_encode($msg);
       
    }
    
}


?>