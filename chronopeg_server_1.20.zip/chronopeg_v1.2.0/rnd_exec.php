<?php 

require_once '../db.php';

header("Content-Type: text/plain");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: X-Requested-With");

date_default_timezone_set('Asia/Manila');
//echo date('Y-m-d H:i:s');

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $datetime = date('Y-m-d H:i:s');
    
    if(isset($_POST['action']) == 'Save Report') {

        $reviewer_id = trim(filter_var($_POST['reviewer_id'], FILTER_SANITIZE_STRING));     
        $rnd_component = trim(filter_var($_POST['rnd_component'], FILTER_SANITIZE_STRING)); 
        $rnd_type = trim(filter_var($_POST['rnd_type'], FILTER_SANITIZE_STRING)); 
        $rnd_remarks = trim(filter_var($_POST['rnd_remarks'], FILTER_SANITIZE_STRING)); 
        
        $stmt0 = $connection->prepare("INSERT INTO rnd (reviewer_id, rnd_component, rnd_type, rnd_remarks, created_at, updated_at) VALUE (:rid, :rcom, :rtyp, :rmark, :ca, :ua)");
        $stmt0->bindParam(':rid', $reviewer_id);
        $stmt0->bindParam(':rcom', $rnd_component);
        $stmt0->bindParam(':rtyp', $rnd_type);
        $stmt0->bindParam(':rmark', $rnd_remarks);
        $stmt0->bindParam(':ca', $datetime);
        $stmt0->bindParam(':ua', $datetime);
        if($stmt0->execute()){
            $arr['exec_message'] = 'Success!';
        }
        else {
            $arr['exec_message'] = 'Failed!';
        }
        
        echo json_encode($arr);
    }
    
}


?>