<?php 

require_once '../db.php';

header("Content-Type: text/plain");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: X-Requested-With");



if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $arr['isPost'] = 'Yes!';
    
    if($_POST['action'] == 'Add New Reviewer') {
        
        $tm_id = $_POST['tm_id'];  
        $dayoff = $_POST['dayoff'];
        $lastname = $_POST['lastname'];     
        $firstname = $_POST['firstname'];     
        $username = $_POST['username'];     
        $password = $_POST['password'];
        
        
        $stmt = $connection->prepare("INSERT INTO reviewers (tm_id, lastname, firstname, username, password, dayoff) VALUES(:tid, :lname, :fname, :uname, :pass, :doff)");
        $stmt->bindParam(':tid', $tm_id);
        $stmt->bindParam(':lname', $lastname);
        $stmt->bindParam(':fname', $firstname);
        $stmt->bindParam(':uname', $username);
        $stmt->bindParam(':pass', $password);
        $stmt->bindParam(':doff', $dayoff);
        if($stmt->execute()){
             $arr['exec_message'] = 'Success!';
        }
        else {
            $arr['exec_message'] = 'Failed!';
        }
        
    }
    
    if($_POST['action'] == 'Reviewer Change Status') {
        
        $reviewer_id = $_POST['reviewer_id'];     
        $reviewer_status = $_POST['reviewer_status']; 
        
        $stmt = $connection->prepare("UPDATE reviewers SET status = :rstatus WHERE reviewer_id = :rid");
        $stmt->bindParam(':rstatus', $reviewer_status);
        $stmt->bindParam(':rid', $reviewer_id);
        if($stmt->execute()){
             $arr['exec_message'] = 'Success!';
        }
        else {
            $arr['exec_message'] = 'Failed!';
        }
        
    }
    
    echo json_encode($arr);
    
}


?>