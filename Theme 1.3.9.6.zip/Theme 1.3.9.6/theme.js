var console, handleGUI = function() {
       //$("body").tooltip({ selector: '[data-toggle=tooltip]' });
},

    handleTheme = function() {

	if(localStorage.getItem('theme') == 'enabled'){

	console.log('ok theme');
	
	$('body').prepend('<style></style>');

	var bodyStyle = 'body{background: #141d26 !important; color: #fff;}';
	$('style').append(bodyStyle);

	var hyperLink = 'body a {color: #fff;} .uiDataTable {color: #eff1f3} .uiDataTable .clickableRow:hover td {background-color: #2a3d52}';
	$('style').append(hyperLink);

	var panel = '.uiBoxLightblue, ._5h92 {background: #243447; color: #fff;}';
	$('style').append(panel);

	var panel1 = '._5h92 {background: #243447 !important; color: #fff; border: 1px solid #31455d !important; } ._5h7n {border-bottom-color: #31455d !important;} ._5h7n div{color: #fff !important}';
	$('style').append(panel1);

	var sidebar = '._4-u8 {background: #243447; color: #fff;} ._mog{background: #253b54; color: #fff} ._5auv a, ._c24 {color: #fff} ._57mb._1u44, ._4-u2 {border: 1px solid #31455d; } ._4-u2>._4-u3 {border-top: 1px solid #32465f} ._5auv ._5auw a:hover {background: #2f445dc9}';
	$('style').append(sidebar);
	
	var tableHome = '.uiDataTable .odd td {background: #2a3d52} label {color: #fff} ._4-ss>thead>tr>th, ._4-ss>thead>tr>td {color: #fff; border-bottom: 1px solid #31455d;box-shadow: 0 1px 1px #31455d; background: #253b54; text-shadow: none}';
	$('style').append(tableHome);

	var tbOnTheJob = '._4-ss>tbody>._1isx:nth-child(even):hover>td, ._4-ss>tbody>._1isx:nth-child(even):hover>th, ._4-ss>tbody>tr:nth-child(even)>td, ._4-ss>tbody>tr:nth-child(even)>th {background: #2a3d52;  }  ._4-ss>*>tr>td {color: #fff} ._4-ss>tbody>tr:hover>td, ._4-ss>tbody>tr:hover>th {background: #344961} ._51mx h2 {color: #fff !important} ._3sts {color: #fff} ._51mx > td {color: #fff !important} .uiBoxWhite {background-color: #243447; border: 1px solid #31455d;}';
	$('style').append(tbOnTheJob);

	

	var tableHome = '._ww- {background: #243447 !important} ._3lxv {background: #253b54 !important; border-bottom: 1px solid #31455d !important;} ._4-sv {background: #243447; border: 1px solid #31455d} table._5tss td {color: #fff}';
	$('style').append(tableHome);

	var homeButton = '._517h, ._59pe:focus, ._59pe:hover{    background-color: #03A9F4;border-color: #159ad6;color: #fff;border-radius: 20px;padding: 1px;min-width: 75px;}';
	$('style').append(homeButton);	

	var tbOnTheJob = '._7dp1 {background-color: #243447} ._962 {background: #1f2e40; border-top: #31455d}';
	$('style').append(tbOnTheJob);

	}
    },
handleTaggingTree = function(){	

	var currComp = localStorage.getItem('currentComponent');

	/*$(document).on('click', '._5tss ._42ft._4jy0._4jy3._517h._51sy', function(){

		var parentRow = $(this).closest('tr').attr('id');
		var compNameId =  '#'+parentRow;
		var compName =  $(compNameId).find('.firstRow').text();
		localStorage.setItem('testComponent', compName);
		
		if(localStorage.getItem('testComponent').toLowerCase().indexOf('title') != -1){
			localStorage.setItem('currentComponent', 'title');
		}
		if(localStorage.getItem('testComponent').toLowerCase().indexOf('body') != -1){
			localStorage.setItem('currentComponent', 'body');
		}
		if(localStorage.getItem('testComponent').toLowerCase().indexOf('image') != -1){
			localStorage.setItem('currentComponent', 'image');
		}
		if(localStorage.getItem('testComponent').toLowerCase().indexOf('video') != -1){
			localStorage.setItem('currentComponent', 'video');
		}
		if(localStorage.getItem('testComponent').toLowerCase().indexOf('english ad') != -1){
			localStorage.setItem('currentComponent', 'english ad');
		}
		
	});*/
	

	fetchComponentF();

	var jobId = '';
	var fetchId = '';
	var realTimeId = '';
	var currentId = '';
	var nextId = '';
	var sec = 0;
	var hasJob = false;

	var getComponent = null;
	var getRealComponent = null;

	function fetchComponentF(){
		var fetchIdTimer = setInterval(function(){

		fetchId = $('._3-90._c24 a span').attr('value');
		getComponent = $('._4bl7._3-9a span').eq(1).text();
		
		$('.queue-c').text('Waiting for queue.');		

		if(typeof fetchId != 'undefined' && getComponent != ''){

			if(getComponent.toLowerCase().indexOf('title') != -1){
				localStorage.setItem('currentComponent', 'title');
			}
			if(getComponent.toLowerCase().indexOf('body') != -1){
				localStorage.setItem('currentComponent', 'body');
				
			}
			if(getComponent.toLowerCase().indexOf('image') != -1){
				localStorage.setItem('currentComponent', 'image');
			}
			if(getComponent.toLowerCase().indexOf('video') != -1){
				localStorage.setItem('currentComponent', 'video');
			}
			if(getComponent.toLowerCase().indexOf('english ad') != -1){
				localStorage.setItem('currentComponent', 'english ad');
			}

			$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			hasJob = true;
			clearInterval(fetchIdTimer);
		
			realTimerFetchF();
		}

		}, 1000);
	}	

	function realTimerFetchF(){

		var realTimer = setInterval(function(){

			if(hasJob){
	
				realTimeId = $('._3-90._c24 a span').attr('value');

				getComponentS = $('._4bl7._3-9a span').eq(1).text().split(' ');
		
				getRealComponent = (getComponent == '' && typeof getComponent == 'undefined') ? getRealComponent = 'Waiting for queue.' : getRealComponent = getComponentS[5] + ' - ' + getComponentS[7] +' '+ getComponentS[8]; 
	
				$('.queue-c').text(getRealComponent);

				sec++;

				if(fetchId != realTimeId){

					sec = 0;
					clearInterval(realTimer);
					fetchComponentF();
	
				}
		
				//console.log(sec);
			}

		}, 1000);
	}

	$(document).on('click', '._42ft', function(){
		var pn = $(this).attr('data-tooltip-content');
		if(pn == 'Previous' || pn == 'Next' || pn == 'Reload current job'){
			tagStopper = 0;
			isSubmitClicked = 0;
		}
	});

	var isSubmitClicked = 0;
	var tagStopper = 0;

	$(document).on('click', '._6_fv._3qn7._6twl._2fyi._1a9e button', function(){
		isSubmitClicked++;
		//console.log(isSubmitClicked);
	});

	$(document).on('keydown', function(e){

	if(e.which == 13){
		isSubmitClicked++;
		tagStopper = 0;
		//console.log(isSubmitClicked);
	}
		
	if(e.which == 27){
		tagStopper = 0;
		isSubmitClicked = 0;
		//console.log('Stopper: ' + tagStopper);

		$('.tagging-tree-logs').html('');
		$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");
	}

	if(e.which == 37 || e.which == 39){
		tagStopper = 0;
		isSubmitClicked = 0;
		$('.tagging-tree-logs').html('');
		$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");
	}
		
	if(localStorage.getItem('taggingTreeKey') == 'key1'){
		if((e.which == 109 && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body')){
			
			

			if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				tbComponent();
			} else if(isSubmitClicked == 4){

				isSubmitClicked = 0;
				tagStopper = 0;

				tbComponent();

			} else {
				//console.log('Something went wrong!');
			}


		}

		if((e.which == 107 && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'image' || currComp == 'video')){

			if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				imComponent();
			} else if(isSubmitClicked == 4){

				isSubmitClicked = 0;
				tagStopper = 0;

				imComponent();

			} else {
				//console.log('Something went wrong!');
			}
			

		}
	}
	else if(localStorage.getItem('taggingTreeKey') == 'key2'){
		
		if(((e.which == 84 || e.which == 66) && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body')){
			
			tbStopper()

		}

		if(((e.which == 73 || e.which == 86 || e.which == 69) && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'image' || localStorage.getItem('currentComponent') == 'video' || localStorage.getItem('currentComponent') == 'english ad')){
			
			ivStopper();
		}
		

	}
	
	else if(localStorage.getItem('taggingTreeKey') == 'key3'){
		
		if(e.which == 107 && localStorage.getItem('taggingTree') == 'enabled'){

			if(localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body'){
				tbStopper();
			}
			else if(localStorage.getItem('currentComponent') == 'image' || localStorage.getItem('currentComponent') == 'video'){
				ivStopper();
			}
			else if(localStorage.getItem('currentComponent') == 'english ad'){
				ivStopper();
			}
			

		}

	}

	function tbStopper(){
		if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				tbComponent();
			} else if(isSubmitClicked == 5){

				isSubmitClicked = 0;
				tagStopper = 0;

				tbComponent();
	
				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			} else {
				//console.log('Something went wrong!');
			}
	}

	function ivStopper(){
		if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				imComponent();
			} else if(isSubmitClicked == 5){

				isSubmitClicked = 0;
				tagStopper = 0;

				imComponent();

				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			} else {
				//console.log('Something went wrong!');
			}
	}

	});

	function tbComponent(){
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Government Body</span>');
			},500);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				jQuery('._6_fv._3qn7._6twl._2fyi._1a9e button').click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Figure or Position</span>');
			},600);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Election mention</span>');
			},700);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Party</span>');
			},800);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				jQuery('._6_fv._3qn7._6twl._2fyi._1a9e button').click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Endorsement, Fundraising and Vote for or against</span>');
			},900);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">Waiting for confirmation.</span>');
			},1000);
	}

	function imComponent(){


		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').html('');
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Government Body Mention</span>');
		},500);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political figure or Public office position</span>');
		},600);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political figure in the image</span>');
		},700);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Election mention</span>');
		},800);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Party</span>');
		},900);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No, Endorsement, Fundraising and Vote for or against</span>');
		},1000);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No, GOTV mention</span>');
		},1100);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">Waiting for confirmation.</span>');
		},1200);
		
			
	}

	$(document).on('click', '.hotkey-icon', function(){

		$('.key1, .key2, .key3').css('color', '#1c1e21');
		$('.label-key1').text('KEY 1');
		$('.label-key2').text('KEY 2');
		$('.label-key3').text('KEY 3');
		$('.label-key1, .label-key2, .label-key3').css('background', '#4cd964');
		
		$(this).find('.key').css('color', '#00BCD4');

		if($(this).attr('data-hotkey') == 'key1'){
			localStorage.setItem('taggingTreeKey', 'key1');
		
			$('.key1').css('color', '#00BCD4');
			$('.label-key1').text('KEY 1 ON');
			$('.label-key1').css('background', '#F44336');

		} else if($(this).attr('data-hotkey') == 'key2'){
			localStorage.setItem('taggingTreeKey', 'key2');
			
			$('.key2').css('color', '#00BCD4');
			$('.label-key2').text('KEY 2 ON');
			$('.label-key2').css('background', '#F44336');

		} else if($(this).attr('data-hotkey') == 'key3'){
			localStorage.setItem('taggingTreeKey', 'key3');
			
			$('.key3').css('color', '#00BCD4');
			$('.label-key3').text('KEY 3 ON');
			$('.label-key3').css('background', '#F44336');

		}
		
		//console.log($(this).attr('data-hotkey'));
	
	});	

	
	var chkSwitcherCtr = 0;

	var chkSwitcher = setInterval(function(){
		
		chkSwitcherCtr++;
		//console.log(chkSwitcherCtr);

		

		if(chkSwitcherCtr <= 10){
			if(localStorage.getItem('taggingTree') == 'enabled'){
				$('#tagging-tree-c').attr('checked','checked')
			} else {
				$('#tagging-tree-c').prop('checked', false);
			}
		
			if(localStorage.getItem('taggingTreeKey') == 'key1'){
				$('.key1').css('color', '#00BCD4');
				$('.label-key1').text('KEY 1 ON');
				$('.label-key1').css('background', '#F44336');
			}
			else if(localStorage.getItem('taggingTreeKey') == 'key2'){
				$('.key2').css('color', '#00BCD4');
				$('.label-key2').text('KEY 2 ON');
				$('.label-key2').css('background', '#F44336');
			}
			else if(localStorage.getItem('taggingTreeKey') == 'key3'){
				$('.key3').css('color', '#00BCD4');
				$('.label-key3').text('KEY 3 ON');
				$('.label-key3').css('background', '#F44336');
			}
			
		} else {
			clearInterval(chkSwitcher);
		}
		

	},1000);

	$(document).on('click', '.tagging-tree-l', function(){
		
		if($('#tagging-tree-c').is(":checked")){
			localStorage.setItem('taggingTree', 'disabled');
		}else {
			localStorage.setItem('taggingTree', 'enabled');
		}
	});

	$(document).on('keydown', function(e){
		if(e.which == 32){
			var ssrl = $(document).scrollTop();
			$("html, body").animate({ scrollTop: ssrl + 800 }, 200);
		}
	});

},
handleGlobalWiki = function(){

$(document).on('keydown', function(e){

	if(e.which == 105){
		if($('._54n6._54n5._y_o')[0]){
			jQuery('._54n6._54n5._y_o ._y_p').click();
		}
	}

});

},
handleVideoToIframe = function(){

$(document).on('keydown', function(e){
	if(e.which == 106 && localStorage.getItem('videoToIframe') == 'enabled'){

		var url = prompt('Enter your Video URL!');
		url = url.replace('/watch?v=','/embed/');

		if($('video')[0]){
		
			if(url != ''){
				$('video').replaceWith('<iframe frameborder="0" width="720" height="480" src="'+url+'"></iframe>');
			}else{	
				console.log('Video To Iframe Error');
			}
		}
		else if($('iframe')[0]){
			if(url != ''){
				$('iframe').attr('src', url);
			}else{	
				console.log('Video To Iframe Error');
			}
		
		}

	}
});

},
handleConsole = function(){



$(document).on('keydown', function(e){

	if(e.which == 111){
		console = prompt('Command Line Interface.');
			if(console.toLowerCase() == 'disable theme'){
				localStorage.setItem('theme', 'disabled');
			}else if(console.toLowerCase() == 'enable theme'){
				localStorage.setItem('theme', 'enabled');
			}else if(console.toLowerCase() == 'disable tagging tree'){
				localStorage.setItem('taggingTree', 'disabled');
			}else if(console.toLowerCase() == 'enable tagging tree'){
				localStorage.setItem('taggingTree', 'enabled');
			}else if(console.toLowerCase() == 'disable videoflix'){
				localStorage.setItem('videoToIframe', 'disabled');
			}else if(console.toLowerCase() == 'enable videoflix'){
				localStorage.setItem('videoToIframe', 'enabled');
			}else if(console.toLowerCase() == 'disable app'){
				localStorage.setItem('app', 'disabled');
			}else if(console.toLowerCase() == 'enable app'){
				localStorage.setItem('app', 'enabled');
			} else if(console.toLowerCase() == 'kronos'){

				var kronosUser = prompt('Kronos Username');
				var kronosPass = prompt('Kronos Password');
	
				localStorage.setItem('kronosUsername', kronosUser);
				localStorage.setItem('kronosPassword', kronosPass);


			} else if(console.toLowerCase() == 'jeonsoft'){
				
				var jeonsoftUser = prompt('Jeonsoft Username');
				var jeonsoftPass = prompt('Jeonsoft Password');

				localStorage.setItem('jeonsoftUsername', jeonsoftUser);
				localStorage.setItem('jeonsoftPassword', jeonsoftPass);

			}
	 		else if(console.toLowerCase() == 'reset local accounts'){

				localStorage.setItem('kronosUsername', '');
				localStorage.setItem('kronosPassword', '');

				localStorage.setItem('jeonsoftUsername', '');
				localStorage.setItem('jeonsoftPassword', '');

			}
	 		else if(console.toLowerCase() == 'key 1'){

				localStorage.setItem('taggingTreeKey', 'key1');

			}
			else if(console.toLowerCase() == 'key 2'){

				localStorage.setItem('taggingTreeKey', 'key2');

			}
			else if(console.toLowerCase() == 'key 3'){

				localStorage.setItem('taggingTreeKey', 'key3');

			}
			else if(console.toLowerCase() == 'ctg'){

				alert('Select Target');

				handleInactiveSrt();

			}
			else {
				console.log('Unknown Command!');
			}
	}
});

},
handleAppLogin = function(){

//console.log($('._1yb2 span').text());
//console.log($('._8u._42ef span').eq(0).text());

var revName = $('._1yb2 span').text();
var revId = $('._8u._42ef span').eq(0).text();
var revLogin = false;

var validCredentials = ['ID: 100026470687755', 'ID: 378032696130120', 'ID: 100026824483680', 'ID: 100025280061074', 'ID: 100026294242411', 'ID: 100029848547072'];

for(var i = 0; i < validCredentials.length; i++){
	if(revId == validCredentials[i]){
		revLogin = true;
		localStorage.setItem('revLogin', revLogin);
		break;
	}
}

var revIdCtr = localStorage.getItem('revIdCtr');

if(window.location.href == 'https://review.intern.facebook.com/intern/review/user/'){
	localStorage.setItem('loginTry', 1);
	console.log(localStorage.getItem('loginTry'));
}

if(revIdCtr != "1" && localStorage.getItem('loginTry') == 1){
	localStorage.setItem('revIdCtr', 0);
	console.log('Rev CTR Start');
	
	//console.log('Name: ' + localStorage.getItem('revName') +' : '+ 'ID: '+localStorage.getItem('revId'));

	localStorage.setItem('revName', revName);
	localStorage.setItem('revId', revId);
	localStorage.setItem('revIdCtr', 1);
	
	//console.log('Name: ' + localStorage.getItem('revName') +' : '+ 'ID: '+localStorage.getItem('revId'));

	window.location.href = "https://review.intern.facebook.com/intern/review/";

}


	if((localStorage.getItem('revName') != '' && localStorage.getItem('revId') != '') && (localStorage.getItem('revName') != '' && localStorage.getItem('revId') != null) && (localStorage.getItem('revLogin') != '' && localStorage.getItem('revLogin') != null)){

		setTimeout(function(){
			$('.srt-login').css('display', 'none');
			$('.highlighter-component, .srt-header').css('display', 'block');
			$('.login-user').append('Hi, '+localStorage.getItem('revName'));
		}, 1000);

		console.log('Reviewer Credential Success');

	}
	else {
		setTimeout(function(){
			$('.srt-login').css('display', 'block');
			$('.highlighter-component, .srt-header').css('display', 'none');
		}, 1000);
		console.log('Reviewer Credential is Empty');
	}

//Reset

/*localStorage.setItem('revName', null);
localStorage.setItem('revId', null);
localStorage.setItem('revLogin', null);
localStorage.setItem('revIdCtr', 0);
localStorage.setItem('loginTry', 0)*/



},


handleInactiveSrt = function() {

var targetElement = null;

$(document).on('click', function(){



});

 var targetElement = null;

  return {
    innerFunction1: function() {
      return privateVar;
    },
    doSomething: function(newString) {
      privateVar = newString;
    }
  };

},
handleAccountCredentials = function(){

var userEl = $('#username');
var passEl = $('#passInput');

var localKronosUser = localStorage.getItem('kronosUsername');
var localKronosPass = localStorage.getItem('kronosPassword');

if(($('#username')[0] && $('#passInput')[0]) && (localKronosUser != '' && localKronosPass!= '')){

	setTimeout(function(){
		userEl.val(localKronosUser);
	},1000);

	setTimeout(function(){
		passEl.val(localKronosPass);
	},2000);
	
	setTimeout(function(){
		
		if(localKronosUser != '' || localKronosPass != ''){
			$('#loginSubmit').click();
		}
	},3000);
	
}


var jUserEl = $('#loginEmployeeCode');
var jPassEl = $('#loginPassword');

var localJsUser = localStorage.getItem('jeonsoftUsername');
var localJsPass = localStorage.getItem('jeonsoftPassword');

if($('#loginEmployeeCode')[0] && $('#loginPassword')[0]){

	setTimeout(function(){
		jUserEl.val(localJsUser);
	},1000);

	setTimeout(function(){
		jPassEl.val(localJsPass);

	},2000);
	
	setTimeout(function(){
		

		if(localJsUser != '' || localJsPass != ''){
			$('.submit.button').click();
		}

	},3000);
	
}

},
handleAppSettings = function(){

console.log('app settings ok!');

if(localStorage.getItem('theme') == null){localStorage.setItem('theme', 'disabled')}
if(localStorage.getItem('taggingTree') == null){localStorage.setItem('taggingTree', 'enabled')}
if(localStorage.getItem('videoToIframe') == null){localStorage.setItem('videoToIframe', 'disabled')}
if(localStorage.getItem('taggingTreeKey') == null){localStorage.setItem('taggingTreeKey', 'key3')}
if(localStorage.getItem('jeonsoftUsername') == null){localStorage.setItem('jeonsoftUsername', '')}
if(localStorage.getItem('jeonsoftPassword') == null){localStorage.setItem('jeonsoftPassword', '')}
if(localStorage.getItem('kronosUsername') == null){localStorage.setItem('kronosUsername', '')}
if(localStorage.getItem('kronosPassword') == null){localStorage.setItem('kronosPassword', '')}
if(localStorage.getItem('app') == null){localStorage.setItem('app', 'enabled')}

console.log('Theme: ' + localStorage.getItem('theme'));
console.log('Tagging Tree: ' + localStorage.getItem('taggingTree'));
console.log('Tagging Tree Key: ' + localStorage.getItem('taggingTreeKey'));
console.log('Video to Iframe: ' + localStorage.getItem('videoToIframe'));
console.log('App: ' + localStorage.getItem('app'));
console.log('Component: ' + localStorage.getItem('currentComponent'));
console.log('Version: 1.3.8.6 (Latested)');

	var welMessage = localStorage.getItem('welMessage');
	var wMessage = '';
	
	wMessage += "Notes: \n";
	wMessage += "Press Esc or Escape key if Auto Tag isn't working \n \n";
	wMessage += "Update as of 9:47 PM 7/29/2019 \n \n";
	wMessage += "(+) Added SRT Login ! \n";
	wMessage += "(+) Added App GUI ! \n";
	wMessage += "(+) Improved Auto Tagging Accuracy ! \n";
	wMessage += "(+) Added English Ad Component ! \n";
	wMessage += "(+) Jeonsoft and Kronos Auto Login \n \n";
	wMessage += "SRT Version 1.3.8.6 \n Hero for Fun";

	setTimeout(function(){
	
	if(welMessage != "1"){
		localStorage.setItem('welMessage', 0);
		alert(wMessage);
		localStorage.setItem('welMessage', 1);	
	}

	},5000);

	


},
handleSrtGUI = function(){

$('body').prepend('<div class="srtTotalReviewTime bootstrap inspinia" style="display: none"></div>');

$.get(chrome.extension.getURL('apple/blank.html'), function(data) {
	$(data).appendTo('.srtTotalReviewTime');
});


var insrtCtr = 0;

$(document).on('keydown', function(e){
	
	

	if(e.which == 45){

		insrtCtr++;

		if(insrtCtr == 1){

		
			
			$('.srtTotalReviewTime').css('display', 'block');
			$('.srtTotalReviewTime').addClass('animated fadeIn');

			setTimeout(function(){
				$('.srtTotalReviewTime').removeClass('animated fadeIn');
			}, 1000);
			

		} else {
			$('.srtTotalReviewTime').css('display', 'none');
			insrtCtr = 0;


		}
	
		
	}

});


$(document).on('click', '.comp-back', function(){
	goBack();
});

$(document).on('click', '.link-auto-tag', function(e){
	e.preventDefault();
	animationClick('.link-auto-tag', '.auto-tagging-component', 'fadeOutLeft');
});

$(document).on('click', '.link-highlighter', function(e){
	e.preventDefault();
	animationClick('.link-highlighter', '.highlighter-component', 'fadeOutLeft');
});

function goBack(){
	
	$('.auto-tagging-component').css('display', 'none');

	$('.widget-home').css('display', 'block');

}


function animationClick(link, target, animation) {
    link = $(link);
    target = $(target);
    link.click(
        function () {
            target.addClass('animated ' + animation);
        },
        function () {
            //wait for animation to finish before removing classes
            window.setTimeout(function () {
                target.removeClass('animated ' + animation);
            }, 2000);
        });
}


// Current Time

setInterval(function(){
	$('.srt-time').text(formatAMPM(new Date));
}, 1000);

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ampm;
  return strTime;
}



},
handleTotalReviewTime = function(){



fetchasd();

var jobId = '';
var fetchId = '';
var realTimeId = '';
var currentId = '';
var nextId = '';
var sec = 0;
var hasJob = false;


function fetchasd(){
	var fetchIdTimer = setInterval(function(){

	fetchId = $('._3-90._c24 a span').attr('value');

	if(typeof fetchId != 'undefined'){

		//sec++;
		hasJob = true;
		clearInterval(fetchIdTimer);
		
		//console.log(sec);
		realTimerF();
	}

	}, 1000);
}

var idArray = [];

function realTimerF(){

var realTimer = setInterval(function(){

	if(hasJob){
	
		realTimeId = $('._3-90._c24 a span').attr('value');

		sec++;

		if(fetchId != realTimeId && keyArrowLeft == false && keyArrowRight == false){
			currentId = realTimeId;
			sec = 0;
			clearInterval(realTimer );
			fetchasd();
	
		}
		

		//console.log(sec);
	}

}, 1000);

var keyArrowLeft = false;
var keyArrowRight = false;

$(document).on('keydown', function(e){
	if(e.which == 37){
		keyArrowLeft = true;
		keyArrowRight = false;
	}
});

$(document).on('keydown', function(e){
	if(e.which == 39){
		keyArrowRight = true;
		keyArrowLeft = false;
	}
});


}


},
handleHighlighterCore = function(){

	/*
	 * Usage:
	 *   // wrap every occurrance of text 'lorem' in content
	 *   // with <span class='highlight'> (default options)
	 *   $('#content').highlight('lorem');
	 *
	 *   // search for and highlight more terms at once
	 *   // so you can save some time on traversing DOM
	 *   $('#content').highlight(['lorem', 'ipsum']);
	 *   $('#content').highlight('lorem ipsum');
	 *
	 *   // search only for entire word 'lorem'
	 *   $('#content').highlight('lorem', { wordsOnly: true });
	 *
	 *   // don't ignore case during search of term 'lorem'
	 *   $('#content').highlight('lorem', { caseSensitive: true });
	 *
	 *   // wrap every occurrance of term 'ipsum' in content
	 *   // with <em class='important'>
	 *   $('#content').highlight('ipsum', { element: 'em', className: 'important' });
	 *
	 *   // remove default highlight
	 *   $('#content').unhighlight();
	 *
	 *   // remove custom highlight
	 *   $('#content').unhighlight({ element: 'em', className: 'important' });
	 */

	jQuery.extend({
	    highlight: function (node, re, nodeName, className) {
	        if (node.nodeType === 3) {
	            var match = node.data.match(re);
	            //console.log(match);
	            if (match) {
	                var highlight = document.createElement(nodeName || 'span');
	                highlight.className = className || 'highlight';
	                var wordNode = node.splitText(match.index);
	                wordNode.splitText(match[0].length);
	                var wordClone = wordNode.cloneNode(true);
	                highlight.appendChild(wordClone);
	                wordNode.parentNode.replaceChild(highlight, wordNode);

	                return 1; //skip added node in parent
	            }
	        } else if ((node.nodeType === 1 && node.childNodes) && // only element nodes that have children
	                !/(script|style)/i.test(node.tagName) && // ignore script and style nodes
	                !(node.tagName === nodeName.toUpperCase() && node.className === className)) { // skip if already highlighted
	            for (var i = 0; i < node.childNodes.length; i++) {
	                i += jQuery.highlight(node.childNodes[i], re, nodeName, className);
	            }
	        }
	        return 0;
	    }
	});

	jQuery.fn.unhighlight = function (options) {
	    var settings = { className: 'highlight', element: 'span' };
	    jQuery.extend(settings, options);

	    return this.find(settings.element + "." + settings.className).each(function () {
	        var parent = this.parentNode;
	        parent.replaceChild(this.firstChild, this);
	        parent.normalize();
	    }).end();
	};

	jQuery.fn.highlight = function (words, options) {
	    var settings = { className: 'highlight', element: 'span', caseSensitive: false, wordsOnly: false };
	    jQuery.extend(settings, options);

	    if (words.constructor === String) {
	        words = [words];
	    }

	    words = jQuery.grep(words, function(word, i){
	      return word != '';
	    });

	    words = jQuery.map(words, function(word, i) {
	      return word.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	    });	    if (words.length == 0) { return this; };

	    var flag = settings.caseSensitive ? "" : "i";
	    var pattern = "(" + words.join("|") + ")";
	    if (settings.wordsOnly) {
	        pattern = "\\b" + pattern + "\\b";
	    }
	    var re = new RegExp(pattern, flag);

	    return this.each(function () {
	        jQuery.highlight(this, re, settings.element, settings.className);
	        jQuery.highlight(this, re, settings.element, settings.className);
	    });
	};
	
},
handleHighlighterExecution = function(){

	setTimeout(function(){
		$('.kword-input').val(localStorage.getItem('govStorage'));
		$('.position-input').val(localStorage.getItem('positionStorage'));
		$('.election-input').val(localStorage.getItem('electionStorage'));
		$('.common-input').val(localStorage.getItem('commonStorage'));
	}, 1000);
	
	var kwordsArr = [];
	var govStorage = '';

	var positionArr = [];
	var positionStorage = '';

	var electionnArr = [];
	var electionStorage = '';

	var commonArr = [];
	var commonStorage = '';

	var posTaggings = '';

	$(document).on('click', '.scan-job', function(){

    		//console.log('Highlighter Execution: Ok!');

		resetHighlight();

		setTimeout(function(){

			highlight('.kword-input', kwordsArr, govStorage, 'govStorage', '.gov-body', 'gov-body', 'Government Body');

			highlight('.position-input', positionArr, positionStorage, 'positionStorage', '.position', 'position', 'Position');

			highlight('.election-input', electionArr, electionStorage, 'electionStorage', '.election', 'election', 'Election');
	
			highlight('.common-input', commonArr, commonStorage, 'commonStorage', '.common', 'common', 'Common Word');

			//resetSrtElementHighlights();
		},500);

		setTimeout(function(){

			
			if($('.gov-body')[0]){
				posTaggings += 'Government Body, ';
			}
			if($('.position')[0]){
				posTaggings += 'Position, ';
			}
			if($('.election')[0]){
				posTaggings += 'Election, ';
			}
		
			$('.tagging-tree-logs').prepend('<p class="log-text-predicted" style="display: block;">Possible taggings for this Job: </p> <p class="log-text"> '+posTaggings.substring(0,posTaggings.lastIndexOf(","))+'</p>');
		},1000);

    		
    	});

	$(document).on('click', '.b-dictionary', function(){
		showHighlightKeyword();
	});

	function resetHighlight(){

		console.log('Reset');

		$('body').unhighlight({ element: 'p', className: 'gov-body' });
		$('body').unhighlight({ element: 'p', className: 'position' });
		$('body').unhighlight({ element: 'p', className: 'election' });
		$('body').unhighlight({ element: 'p', className: 'common' });

		$('.tagging-tree-logs').html('');

		kwordsArr = [];
		localStorage.setItem('govStorage', '');
		
		positionArr = [];
		localStorage.setItem('positionStorage', '');

		electionArr = [];
		localStorage.setItem('electionStorage', '');

		commonArr = [];
		localStorage.setItem('commonStorage', '');

		posTaggings = '';

	}
	
	function resetSrtElementHighlights(){
		$('.srt-element').unhighlight({ element: 'p', className: 'gov-body' });
		$('.srt-element').unhighlight({ element: 'p', className: 'position' });
		$('.srt-element').unhighlight({ element: 'p', className: 'election' });
		$('.srt-element').unhighlight({ element: 'p', className: 'common' });
	}

	function showHighlightKeyword(){
		$('.hgh-form').slideDown();
	}

	function highlight(input, word_arr, storage, storage_text, label_element, label_text, lt_header){
		
		var text = '';
		var log_arr = [];
		var unique_arr = [];
		
		var arrayOfLines = $(input).val().split('\n');

	    	$.each(arrayOfLines, function(index, item) {
	        	if(item != ''){
	        		word_arr.push(item);
				storage += item + '\n';
	       	 	}
	    	});

		localStorage.setItem(storage_text, storage);

		for(var i = 0; i < word_arr.length; i++){
			//$("body").highlight(word_arr[i], { element: 'p', className: label_text, wordsOnly: true });
			$('body').not($('div.srt-element')).highlight(word_arr[i], { element: 'p', className: label_text, wordsOnly: true });

		}

		$(label_element).each(function(){
		  	log_arr.push($(this).text().toLowerCase());  
		});
		
		$.each(log_arr, function(i, el){
			if($.inArray(el, unique_arr) === -1) {
				unique_arr.push(el);
			}
		});
		
		$('.tagging-tree-logs').append('<p class="log-text-header">Possible tag/s for '+lt_header+': </p>');
		
		
		for(var i = 0; i < unique_arr.length; i++){
			text += unique_arr[i] + ', ';
		}
		text = text.substring(0,text.lastIndexOf(","));
		if(text != ''){
			$('.tagging-tree-logs').append('<p class="log-text"> '+text+'</p>');
		} else {
			$('.tagging-tree-logs').append('<p class="log-text">No match found.</p>');
		}
	
		
		
	}

},
handleRealSrtTool = function(){


},
    Main = function() {
        'use strict';

        return {
            init: function() {

		var d = Date.now();
		var appToken = 1585007475000;

		handleAppSettings()
		
		if(d <= appToken && localStorage.getItem('app') == 'enabled'){
			handleGUI(),
			handleTheme(),
			handleTaggingTree(),
			handleGlobalWiki(),
			handleVideoToIframe(),
			handleConsole(),
			handleAppLogin(),
			handleInactiveSrt(),
			handleSrtGUI(),
			handleAccountCredentials(),
			handleTotalReviewTime(),
			handleHighlighterCore(),
			handleHighlighterExecution(),
			handleRealSrtTool()
				
		} else{
			console.log('Something went wrong. Contact Saitama!');
		}
		
            }
        }
    }();
Main.init();

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

function handle_mousedown(e){
    window.my_dragging = {};
    my_dragging.pageX0 = e.pageX;
    my_dragging.pageY0 = e.pageY;
    my_dragging.elem = this;
    my_dragging.offset0 = $(this).offset();
    function handle_dragging(e){
        var left = my_dragging.offset0.left + (e.pageX - my_dragging.pageX0);
        var top = my_dragging.offset0.top + (e.pageY - my_dragging.pageY0);
        $(my_dragging.elem)
        .offset({top: top, left: left});
    }
    function handle_mouseup(e){
        $('body')
        .off('mousemove', handle_dragging)
        .off('mouseup', handle_mouseup);
	console.log('asd');
    }
    $('body')
    .on('mouseup', handle_mouseup)
    .on('mousemove', handle_dragging);
}

$('._7_5a._3qn7._61-0._2fyh._1a9e').mousedown(handle_mousedown);
