/*------------------------------------- 
Project Name: Highlighter
Author: Mark Gidion Enojado
Version: 1.5.2
Date: February 17, 2019
Updated: 12:30 PM 4/1/2019
--------------------------------------*/
var handleHighlighterGUI = function(){
	
	//Append Elements

	$('body').prepend('<div class="highlighterElement bootstrap inspinia" style=""></div>');

 	$.get(chrome.extension.getURL('apple/blank.html'), function(data) {
	    $(data).appendTo('.highlighterElement');
	});


 	$(document).on("click", "[data-click=sidebar-minify]", function(e) {
        e.preventDefault();
        var a = "page-sidebar-minified",
            t = "#page-container";
            s = ".sidebar";
        $(t).hasClass(a) ? $(s).css({'padding-top': '110px', 'transition': '0.3s'}) : $(s).css({'padding-top': '50px', 'transition': '0.3s'});
    });

    /*var h_elements = ['highlighter-content', 'jeonsoft-content', 'kronos-content', 'links-content', 'settings-content'];
    var uniqueElem = [];

 	$(document).on('click', '.highlight-trig', function(){
 	
 		$('.highlighter-content').css('display', 'block');

 		$('.jeonsoft-content, .kronos-content, .links-content, .settings-content').css('display', 'none');

 	});

 	$(document).on('click', '.jeonsoft-trig', function(){
 	
 		$('.jeonsoft-content').css('display', 'block');

 		$('.highlighter-content, .kronos-content, .links-content, .settings-content').css('display', 'none');

 	});

 	$(document).on('click', '.kronos-trig', function(){
 	
 		$('.kronos-content').css('display', 'block');

 		$('.jeonsoft-content, .highlighter-content, .links-content, .settings-content').css('display', 'none');

 	});*/
	var guishowctr = 0;
	$(document).on('keydown', function(e){
		if(e.which == 45){
			guishowctr++;
			if(guishowctr == 1){
				$('.highlighterElement').css('display', 'block');
			}
			else {
				$('.highlighterElement').css('display', 'none');
				guishowctr = 0;
			}
		}
	});
	
	var resizectr = 0;
	$(document).on('click', '[data-click=resize-content]', function(e){
		resizectr++;
		if(resizectr == 1){
			$('.highlighterElement').animate({
				'width': '50%'
			},1000);
		}
		else {
			$('.highlighterElement').animate({
				'width': '350px'
			},1000);
			resizectr = 0;
		}
		
	
	});

	console.log('GUI OK!');


},
handleHighlighterToggle = function(){

	$(document).on('click', '.btn-convert-taggings', function(){

		var tags = $('._4-u2._5p_o._4-u8 div div span span a span').attr('value') + ' N Y NSFA \n';

		for(var i = 0; i < $('._6_3e .ellipsis').length; i++){
			tags += $('._6_3e .ellipsis:eq('+i+')').text() + '\n';
		}
		$('.get-taggings').val(tags);
	});

	$(document).on('click', '.btn-copy-taggings', function(){
		$('.get-taggings').select();
   	 	document.execCommand('copy');
		document.getSelection().removeAllRanges();
	});

	//https://www.youtube.com/watch?v=k-C8a-mnbJU	
	//lfloat _ohe

	var url = '';
	$(document).on('click', '.btn-url', function(){
		url = $('.url').val().replace('/watch?v=','/embed/');
		$('video').replaceWith('<iframe frameborder="0" width="720" height="480" src="'+url+'"></iframe>');
	});

	

	$(document).on('keydown', '.search-kword', function(e){
		
		if(e.which == 13){
			e.preventDefault();
			var search = $(this).val();
			if(search == 'secret'){
				$('.videoToiframe').slideDown();
			}
			else if(search == 'hide secret'){
				$('.videoToiframe').slideUp();
			}
		}
	});

	$(document).on('keydown', function(e){
	
	//console.log(e.which)
		if(e.which == 220){
			var tags = $('._4-u2._5p_o._4-u8 div div span span a span').attr('value') + '\n';

			for(var i = 0; i < $('._6_3e .ellipsis').length; i++){
				tags += $('._6_3e .ellipsis:eq('+i+')').text() + '\n';
			}
			$('.get-taggings').val(tags);

			setTimeout(function(){
				$('.get-taggings').select();
   	 			document.execCommand('copy');
				document.getSelection().removeAllRanges();
				console.log('Copied');
			},1500);
		}	
	
});

},
handleHighlighterCore = function(){

	/*
	 * Usage:
	 *   // wrap every occurrance of text 'lorem' in content
	 *   // with <span class='highlight'> (default options)
	 *   $('#content').highlight('lorem');
	 *
	 *   // search for and highlight more terms at once
	 *   // so you can save some time on traversing DOM
	 *   $('#content').highlight(['lorem', 'ipsum']);
	 *   $('#content').highlight('lorem ipsum');
	 *
	 *   // search only for entire word 'lorem'
	 *   $('#content').highlight('lorem', { wordsOnly: true });
	 *
	 *   // don't ignore case during search of term 'lorem'
	 *   $('#content').highlight('lorem', { caseSensitive: true });
	 *
	 *   // wrap every occurrance of term 'ipsum' in content
	 *   // with <em class='important'>
	 *   $('#content').highlight('ipsum', { element: 'em', className: 'important' });
	 *
	 *   // remove default highlight
	 *   $('#content').unhighlight();
	 *
	 *   // remove custom highlight
	 *   $('#content').unhighlight({ element: 'em', className: 'important' });
	 */

	jQuery.extend({
	    highlight: function (node, re, nodeName, className) {
	        if (node.nodeType === 3) {
	            var match = node.data.match(re);
	            //console.log(match);
	            if (match) {
	                var highlight = document.createElement(nodeName || 'span');
	                highlight.className = className || 'highlight';
	                var wordNode = node.splitText(match.index);
	                wordNode.splitText(match[0].length);
	                var wordClone = wordNode.cloneNode(true);
	                highlight.appendChild(wordClone);
	                wordNode.parentNode.replaceChild(highlight, wordNode);

	                return 1; //skip added node in parent
	            }
	        } else if ((node.nodeType === 1 && node.childNodes) && // only element nodes that have children
	                !/(script|style)/i.test(node.tagName) && // ignore script and style nodes
	                !(node.tagName === nodeName.toUpperCase() && node.className === className)) { // skip if already highlighted
	            for (var i = 0; i < node.childNodes.length; i++) {
	                i += jQuery.highlight(node.childNodes[i], re, nodeName, className);
	            }
	        }
	        return 0;
	    }
	});

	jQuery.fn.unhighlight = function (options) {
	    var settings = { className: 'highlight', element: 'span' };
	    jQuery.extend(settings, options);

	    return this.find(settings.element + "." + settings.className).each(function () {
	        var parent = this.parentNode;
	        parent.replaceChild(this.firstChild, this);
	        parent.normalize();
	    }).end();
	};

	jQuery.fn.highlight = function (words, options) {
	    var settings = { className: 'highlight', element: 'span', caseSensitive: false, wordsOnly: false };
	    jQuery.extend(settings, options);

	    if (words.constructor === String) {
	        words = [words];
	    }

	    words = jQuery.grep(words, function(word, i){
	      return word != '';
	    });

	    words = jQuery.map(words, function(word, i) {
	      return word.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	    });	    if (words.length == 0) { return this; };

	    var flag = settings.caseSensitive ? "" : "i";
	    var pattern = "(" + words.join("|") + ")";
	    if (settings.wordsOnly) {
	        pattern = "\\b" + pattern + "\\b";
	    }
	    var re = new RegExp(pattern, flag);

	    return this.each(function () {
	        jQuery.highlight(this, re, settings.element, settings.className);
	        jQuery.highlight(this, re, settings.element, settings.className);
	    });
	};
	
},
handleHighlighterExecution = function(){

	$('.Q8LRLc').text('Donald Trump for President, Mueller, Obama, Hillary Clinton, Kamala Harris, Michelle, Trump');

	var kwordsArr = [];
	var polLogArr = [];
	var uniquePolNames = [];

	$(document).on('blur', '.kword-input', function(){

    	alert('Highlighter Execution: Ok!');

    	var arrayOfLines = $(this).val().split('\n');
	    $.each(arrayOfLines, function(index, item) {

	        if(item != ''){

	        	kwordsArr.push(item);
	        }

	    });

    	$('body').unhighlight({ element: 'p', className: 'politician' });

		for(var i = 0; i < kwordsArr.length; i++){
			$('body').highlight(kwordsArr[i], { element: 'p', className: 'politician' });

		}

		kwordsArr = [];
		polLogArr = [];
		uniquePolNames = [];
    	$('.logs').html('');

		$('.politician').each(function(){
		  	polLogArr.push($(this).text());		  
		});

		$.each(polLogArr, function(i, el){
			if($.inArray(el, uniquePolNames) === -1) {
				uniquePolNames.push(el);
			}
		});

		console.log(uniquePolNames);

		for(var i = 0; i < uniquePolNames.length; i++){
			$('.logs').append('<p class="log-text">This should be tag for Politician  Name: '+uniquePolNames[i]+'</p>');
		}

    });

},
handleTrackerReport = function(){



$(document).on('click', '.btn-convert', function(e){
	e.preventDefault();
	
	var name = $('.tracker-name').val();
	var component = $('.tracker-component').val();
	var arrayOfLines = $('.data').val().split('\n');

	if(name == '' || component == ''){
		alert('Please complete the fields');
	}
	else {
		$('.waiting').remove();
		$.each(arrayOfLines, function(index, item) {
	  	if(item != ''){

			var arr = item.split(' ');
			var output = '';
			output += '<tr>';
			output += '<td>'+name+'</td>';
			output += '<td>'+component+'</td>';
			output += '<td>#'+arr[0]+'</td>';
			output += '<td>'+arr[1]+'</td>';
			output += '<td>'+arr[2]+'</td>';
			output += '<td>'+arr[3]+'</td>';
			output += (typeof arr[4] === 'undefined') ? '<td></td>' : '<td>'+arr[4]+'</td>';
			output += '</tr>';
			$('.tracker-table').append(output);		
		
	        }
		$('.tracker-component').val('');
		$('.data').val('');

	    });
	}
	    
	

});

$(document).on('click', '.btn-reset', function(e){
	e.preventDefault();
	$('.data').val('');
	$('.tracker-table tbody').html('<tr class="waiting"><td colspan="7" class="text-center">Waiting for Data</td></tr>');
});

$(document).on('click', '.btn-copy', function(e){
	$('.copy-notif').css('display', 'block').addClass('bounceOut');
	setTimeout(function(){
		$('.copy-notif').removeClass('bounceOut').css('display', 'none');
	},1000);
});


function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}

},
handleTrackerTestUpdate = function(){

var lastJobID = '';

$(document).on('click', '.btn-convert', function(e){
	e.preventDefault();
	
	var name = $('.tracker-name').val();
	var component = $('.tracker-component').val();
	var arrayOfLines = $('.data').val().split('\n');
	
	var convert_ctr = 0;

	if(name == '' || component == ''){
		alert('Please complete the fields');
	}
	else {
		$('.waiting').remove();
		$.each(arrayOfLines, function(index, item) {
	  		if(item != ''){

				convert_ctr++;
				
				var tagStrings = '';

				var arr = item.split(' ');
				if(isNaN(arr[0].charAt(0))){ //String
					tagStrings += item + ', ';
				
				}
				else { // Number

					var output = '';
					output += '<tr>';
					output += '<td>'+name+'</td>';
					output += '<td>'+component+'</td>';
					output += '<td>#'+arr[0]+'</td>';
					output += '<td>'+arr[1]+'</td>';
					output += '<td>'+arr[2]+'</td>';
					output += '<td>'+arr[3]+'</td>';

					if(arr.length > 3){

					}

					output += (typeof arr[4] === 'undefined') ? '<td></td>' : '<td>'+arr[4]+'</td>';
					output += '</tr>';
					$('.tracker-table').append(output);

				}		
			
	       		}
			$('.tracker-component').val('');
			$('.data').val('');

	   	 });
		
		$('.convert-msg .alert-msg strong').text(convert_ctr);
		$('.convert-msg').slideDown();
	
	}
	    
	

});

$(document).on('click', '.btn-nsfa-convert', function(e){
	e.preventDefault();
	
	var input = $('.nsfa').val();
	var name = $('.tracker-name').val();
	var component = $('.tracker-component').val();
	var arrayOfLines = $('.nsfa').val().split('\n');
	var convert_nsfa_ctr = 0;

	var tagStrings = '';

	if(input == '' || name == '' || component == ''){
		alert('Please complete the fields');
	}
	else {
		$('.waiting').remove();
		$.each(arrayOfLines, function(index, item) {
	  		if(item != ''){

				var arr = item.split(' ');
				if(isNaN(arr[0].charAt(0))){ //String
				
					tagStrings += item + ', ';
				
				}
				else { // Number

					
				}		
			
	       		}
			else if(item == ''){
				convert_nsfa_ctr++;
				console.log(tagStrings);
				$('.nsfa-table').append('<tr><td>'+tagStrings+'</td></tr>');
				tagStrings = '';
			}

	   	 });

		$('.convert-nsfa-msg .alert-msg strong').text(convert_nsfa_ctr);
		$('.convert-nsfa-msg').slideDown();
		
	}
});

$(document).on('click', '.btn-reset', function(e){
	e.preventDefault();
	$('.data').val('');
	$('.tracker-table tbody').html('<tr class="waiting"><td colspan="7" class="text-center">Waiting for Data</td></tr>');
	$('.convert-msg').slideUp();
});

$(document).on('click', '.btn-nsfa-reset', function(e){
	e.preventDefault();
	$('.nsfa').val('');
	$('.tracker-nsfa-table tbody').html('<tr class="waiting"><td colspan="7" class="text-center">Waiting for Data</td></tr>');
	$('.convert-nsfa-msg').slideUp();
});

$(document).on('click', '.btn-copy, .btn-nsfa-copy', function(e){
	$('.copy-notif').css('display', 'block').addClass('bounceOut');
	setTimeout(function(){
		$('.copy-notif').removeClass('bounceOut').css('display', 'none');
	},1000);
});


function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}

},
handleOneTimeTracker = function(){

//ONE TIME TRACKER. Note: This is not stable update. Expect errors!!!
	
	var convert_ctr = 0;
	var convert_Ctr_t = 0;
	var trlength = -1;

	$(document).on('click', '.btn-convert', function(e){
		e.preventDefault();

		
		var input = $('.data').val();
		var name = $('.tracker-name').val();
		var component = $('.tracker-component').val();
		var arrayOfLines = $('.data').val().split('\n');

		var tagStrings = '';
		

		if(input == '' || name == '' || component == ''){
			alert('Please complete the fields');
		}
		else {
			$('.waiting').remove();
			$.each(arrayOfLines, function(index, item) {
		  		if(item != ''){

					var b = item.split(' ');
					if(!isNaN(b[0].charAt(0))){

						tagStrings = '';
						trlength++;
						convert_ctr++;

						var o = '';
						o += '<tr>';
						o += '<td>'+name+'</td>';
						o += '<td>'+component+'</td>';
						o += '<td>#'+b[0]+'</td>';
			       			o += '<td>'+b[1]+'</td>';
			       			o += '<td>'+b[2]+'</td>';
			       			o += '<td>'+b[3]+'</td>';
			       			o += (typeof b[4] === 'undefined') ? '<td>N/A</td>' : '<td>'+b[4]+'</td>';
						o += (typeof b[5] === 'undefined') ? '<td class="nsfatag">N/A</td>' : '<td class="nsfatag">'+b[5]+'</td>';
			       			//o += '<td class="nsfatag">'+b[5]+'</td>';
			       			o += '</tr>';


			       		//console.log(trlength);
					
					}
					else if(isNaN(b[0].charAt(0))){
		
						console.log(trlength);

						//console.log($('#trackertablebody').length);

						tagStrings += item + '--**-- ';
						
						$('#trackertablebody tr:eq('+trlength+') td:eq(7)').text(tagStrings);
						//$('#trackertablebody tr:eq(0) td:eq(7)').text(tagStrings);

						
					}		
					$('#trackertablebody').append(o);
		       		}
				$('.tracker-component').val('');
				$('.data').val('');

		   	 });

			convert_Ctr_t += convert_ctr;
			$('.convert-msg .alert-msg .totctr').text(convert_Ctr_t);
			$('.convert-msg .alert-msg').append('<span class="msg"><strong>'+convert_ctr+':</strong> Political Classification '+component+'</span>');
			$('.convert-msg').slideDown();

			convert_ctr = 0;
		}
	});

$(document).on('click', '.btn-reset', function(e){
	e.preventDefault();

	trlength = -1;
	convert_ctr = 0;
	convert_Ctr_t = 0;

	$('.data').val('');
	$('#trackertablebody').html('<tr class="waiting"><td colspan="8" class="text-center">Waiting for Data</td></tr>');
	
	$('.convert-msg .alert-msg').html('');
	$('.convert-msg .alert-msg').append('<span class="msg">Converted <strong class="totctr"></strong> records.</span>');
	$('.convert-msg').slideUp();
});

$(document).on('click', '.btn-copy', function(e){
	$('.copy-notif').css('display', 'block').addClass('bounceOut');
	setTimeout(function(){
		$('.copy-notif').removeClass('bounceOut').css('display', 'none');
	},1000);
});


function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}


},
Highlighter = function(){
	'use strict';
	return {
		init: function(){
			handleHighlighterGUI(),
			handleHighlighterToggle(),
			handleHighlighterCore(),
			handleHighlighterExecution(),
			handleOneTimeTracker()
		}
	}
}();

Highlighter.init();

function handle_mousedown(e){
    window.my_dragging = {};
    my_dragging.pageX0 = e.pageX;
    my_dragging.pageY0 = e.pageY;
    my_dragging.elem = this;
    my_dragging.offset0 = $(this).offset();
    function handle_dragging(e){
        var left = my_dragging.offset0.left + (e.pageX - my_dragging.pageX0);
        var top = my_dragging.offset0.top + (e.pageY - my_dragging.pageY0);
        $(my_dragging.elem)
        .offset({top: top, left: left});
    }
    function handle_mouseup(e){
        $('body')
        .off('mousemove', handle_dragging)
        .off('mouseup', handle_mouseup);
    }
    $('body')
    .on('mouseup', handle_mouseup)
    .on('mousemove', handle_dragging);
}

//$('.highlighterElement').mousedown(handle_mousedown);

