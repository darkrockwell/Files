/*-------------------------------------
Project Name: Highlighter
Author: Mark Gidion Enojado
Version: 1.0.0
Date: February 17, 2019
Updated: February 17, 2019
--------------------------------------*/

handleSample = function(){
	
	console.log('Sample OK!');


},
Sample = function(){
	'use strict';
	return {
		init: function(){
			handleSample()
		}
	}
}();


Sample.init();