var handleSrtGUI = function(){

$('body').prepend('<div class="srt-element bootstrap inspinia" style="display: block"></div>');

$.get(chrome.extension.getURL('horizone.html'), function(data) {
	$(data).appendTo('.srt-element');
});


// Current Time

setInterval(function(){
	$('.srt-time').text(formatAMPM(new Date));
}, 1000);

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ampm;
  return strTime;
}



},
handleInterface = function(){

// $('.app-content').slimScroll({
// 	height: '400px'
// });

var gui = false;

$(document).on('keydown', function(e){

	if(e.which == 45){
		
		if(!gui){
			$('.app-block').fadeIn();
			gui = true;
		}
		else {
			$('.app-block').fadeOut();
			gui = false;
		}

		//console.log(gui);
		
	}


});


$(document).on('click', '.get-started', function(){
	$('.app-intro').fadeOut('fast', function(){
		$('.app-header, .app-content, .app-footer').fadeIn('fast');
		$('.highlight-f').fadeIn('fast').css('display', 'flex');
	});
});

$(document).on('click', '.menu-open-button', function(){
   	$('.app-block').fadeIn();
    gui = true;
});

$(document).on('click', '.f-item', function(){

	if ($(this).hasClass('h-home')){

		$('.text2speech-content, .tagging-tree-content, .highlighter-kb-block, .kb-note, .t2s-note, .att-note, .tagging-tree-f').fadeOut('fast', function(){
			$('.highlighter-block, .highlighter-data, .pos-tags, .note-announce').fadeIn('fast');
			$('.highlight-f').fadeIn('fast').css('display', 'flex');
		});

	}
	else if ($(this).hasClass('h-scan-page')){

		// $('.text2speech-content, .tagging-tree-content, .highlighter-kb-block, .kb-note, .t2s-note, .att-note').fadeOut('fast', function(){
		// 	$('.highlighter-block, .highlighter-data, .pos-tags, .note-announce').fadeIn('fast');
		// 	$('.app-footer').fadeIn('fast').css('display', 'flex');
		// });

	}
	else if ($(this).hasClass('h-kb')){
		
		//$('.highlighter-footer hr').css('margin-left', '66.6666666666%');

		// $('.h-home').removeClass('active');
		// $(this).addClass('active');

		// $('.pos-tags, .highlighter-data').fadeOut();
		// setTimeout(function(){
		// 	$('.highlighter-kb-block').fadeIn();
		// },500);

		$('.highlighter-data, .text2speech-content, .tagging-tree-content, .pos-tags, .t2s-note, .att-note').fadeOut('fast', function(){
			$('.highlighter-kb-block, .kb-note').fadeIn('fast');
			$('.highlight-f').fadeIn('fast').css('display', 'flex');
		});
	}

});

/* Menu
--------------------------------------------*/

$(document).on('click', '.menu-item', function(){

	$('.highlighter-data').html('');

	$('.shortcut-menu a').removeClass('active');
	$(this).toggleClass('active');

	if ($(this).hasClass('m-highlight')){

		$('.text2speech-content, .tagging-tree-content, .t2s-note, .att-note, .text2speech-f, .tagging-tree-f, .idle-timer-content, .idle-note').fadeOut(10, function(){
			$('.app-block, .highlighter-block, .pos-tags, .note-announce').fadeIn(1000);
			$('.highlight-f').fadeIn(1000).css('display', 'flex');
		});

	}
	else if ($(this).hasClass('m-texttospeach')){

		$('.highlighter-block, .highlighter-kb-block, .pos-tags, .att-note, .kb-note, .tagging-tree-content, .note-announce, .highlight-f, .tagging-tree-f, .idle-timer-content, .idle-note').fadeOut(100, function(){
			$('.text2speech-content, .t2s-note').fadeIn(1000);
			$('.text2speech-f').fadeIn(1000).css('display', 'flex');
		});

	}
	else if ($(this).hasClass('m-tagging-tree')){

		$('.highlighter-block, .highlighter-kb-block, .pos-tags, .t2s-note, .note-announce, .text2speech-content, .highlight-f, .text2speech-f, .idle-timer-content, .idle-note').fadeOut(100, function(){
			$('.tagging-tree-content, .att-note, .tagging-tree-f').fadeIn(1000);
		});
		
	}
	else if ($(this).hasClass('m-idle-timer')){

		$('.highlighter-block, .highlighter-kb-block, .pos-tags, .t2s-note, .note-announce, .text2speech-content, .highlight-f, .text2speech-f, .tagging-tree-content').fadeOut(100, function(){
			$('.idle-timer-content, .idle-note').fadeIn(1000);
		});
		
	}



});

},
handleHighlighterCore = function(){

	/*
	 * jQuery Highlight plugin
	 *
	 * Based on highlight v3 by Johann Burkard
	 * http://johannburkard.de/blog/programming/javascript/highlight-javascript-text-higlighting-jquery-plugin.html
	 *
	 * Code a little bit refactored and cleaned (in my humble opinion).
	 * Most important changes:
	 *  - has an option to highlight only entire words (wordsOnly - false by default),
	 *  - has an option to be case sensitive (caseSensitive - false by default)
	 *  - highlight element tag and class names can be specified in options
	 *
	 * Usage:
	 *   // wrap every occurrance of text 'lorem' in content
	 *   // with <span class='highlight'> (default options)
	 *   $('#content').highlight('lorem');
	 *
	 *   // search for and highlight more terms at once
	 *   // so you can save some time on traversing DOM
	 *   $('#content').highlight(['lorem', 'ipsum']);
	 *   $('#content').highlight('lorem ipsum');
	 *
	 *   // search only for entire word 'lorem'
	 *   $('#content').highlight('lorem', { wordsOnly: true });
	 *
	 *   // don't ignore case during search of term 'lorem'
	 *   $('#content').highlight('lorem', { caseSensitive: true });
	 *
	 *   // wrap every occurrance of term 'ipsum' in content
	 *   // with <em class='important'>
	 *   $('#content').highlight('ipsum', { element: 'em', className: 'important' });
	 *
	 *   // remove default highlight
	 *   $('#content').unhighlight();
	 *
	 *   // remove custom highlight
	 *   $('#content').unhighlight({ element: 'em', className: 'important' });
	 *
	 *
	 * Copyright (c) 2009 Bartek Szopka
	 *
	 * Licensed under MIT license.
	 *
	 */

	jQuery.extend({
	    highlight: function (node, re, nodeName, className) {
	        if (node.nodeType === 3) {
	            var match = node.data.match(re);
	            if (match) {
	                var highlight = document.createElement(nodeName || 'span');
	                highlight.className = className || 'highlight';
	                var wordNode = node.splitText(match.index);
	                wordNode.splitText(match[0].length);
	                var wordClone = wordNode.cloneNode(true);
	                highlight.appendChild(wordClone);
	                wordNode.parentNode.replaceChild(highlight, wordNode);
	                return 1; //skip added node in parent
	            }
	        } else if ((node.nodeType === 1 && node.childNodes) && // only element nodes that have children
	                !/(script|style)/i.test(node.tagName) && // ignore script and style nodes
	                !(node.tagName === nodeName.toUpperCase() && node.className === className)) { // skip if already highlighted
	            for (var i = 0; i < node.childNodes.length; i++) {
	                i += jQuery.highlight(node.childNodes[i], re, nodeName, className);
	            }
	        }
	        return 0;
	    }
	});

	jQuery.fn.unhighlight = function (options) {
	    var settings = { className: 'highlight', element: 'span' };
	    jQuery.extend(settings, options);

	    return this.find(settings.element + "." + settings.className).each(function () {
	        var parent = this.parentNode;
	        parent.replaceChild(this.firstChild, this);
	        parent.normalize();
	    }).end();
	};

	jQuery.fn.highlight = function (words, options) {
	    var settings = { className: 'highlight', element: 'span', caseSensitive: false, wordsOnly: false };
	    jQuery.extend(settings, options);

	    if (words.constructor === String) {
	        words = [words];
	    }
	    words = jQuery.grep(words, function(word, i){
	      return word != '';
	    });
	    words = jQuery.map(words, function(word, i) {
	      return word.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	    });
	    if (words.length == 0) { return this; };

	    var flag = settings.caseSensitive ? "" : "i";
	    var pattern = "(" + words.join("|") + ")";
	    if (settings.wordsOnly) {
	        pattern = "\\b" + pattern + "\\b";
	    }
	    var re = new RegExp(pattern, flag);

	    return this.each(function () {
	        jQuery.highlight(this, re, settings.element, settings.className);
	    });
	};

},
handleHighlighterExec = function(){

	var kwordsArr = [];
	var govStorage = '';

	var positionArr = [];
	var positionStorage = '';

	var electionnArr = [];
	var electionStorage = '';

	var commonArr = [];
	var commonStorage = '';

	var posTaggings = '';
	
	//For Testing Purposes
	
    if($('.kword-input').val() == ''){
       $(this).val('parliament');
    }
    if($('.position-input').val() == ''){
        $(this).val('president');
    }

	$('.kword-input').val(localStorage.getItem('govStorage'));
	$('.position-input').val(localStorage.getItem('positionStorage'));

	//var pol_labels = $('.kword-input').val().trim().split('\n');

	$(document).on('click', '.h-scan-page', function(){

		resetHighlight();
		$('.highlighter-data').html('');

		setTimeout(function(){

	    	// $.each(pol_labels, function(index, label) {
	     //    	if(label != ''){
	     //    		if(label == '!BODY'){
	     //    			alert('Body!');
	     //    		}
	     //    		else if(label == '!POSITION'){
	     //    			alert('Position!')
	     //    		}
	     //   	 	}
	    	// });

			highlight('.kword-input', kwordsArr, govStorage, 'govStorage', '.gov-body', 'gov-body', 'Government Body');

			highlight('.position-input', positionArr, positionStorage, 'positionStorage', '.position', 'position', 'Position');

			// highlight('.election-input', electionArr, electionStorage, 'electionStorage', '.election', 'election', 'Election');
	
			// highlight('.common-input', commonArr, commonStorage, 'commonStorage', '.common', 'common', 'Common Word');

		},500);

		setTimeout(function(){

			
			if($('.gov-body')[0]){
				posTaggings += 'Government Body, ';
			}
			if($('.position')[0]){
				posTaggings += 'Position, ';
			}
			if($('.election')[0]){
				posTaggings += 'Election, ';
			}

			$('.pos-tags-text').text(posTaggings.substring(0,posTaggings.lastIndexOf(",")));


		},1000);
    		
    	});

	$(document).on('click', '.b-dictionary', function(){
		showHighlightKeyword();
	});


	function highlight(input, word_arr, storage, storage_text, label_element, label_text, lt_header){
		
		var text = '';
		var log_arr = [];
		var unique_arr = [];
		
		var arrayOfLines = $(input).val().split('\n');

	    	$.each(arrayOfLines, function(index, item) {
	        	if(item != ''){
	        		word_arr.push(item);
				storage += item + '\n';
	       	 	}
	    	});

		localStorage.setItem(storage_text, storage);

		for(var i = 0; i < word_arr.length; i++){
			//$("body").highlight(word_arr[i], { element: 'p', className: label_text, wordsOnly: true });
			$('body').not($('div.srt-element')).highlight(word_arr[i], { element: 'p', className: label_text, wordsOnly: true });

		}

		$(label_element).each(function(){
		  	log_arr.push($(this).text().toLowerCase());  
		});
		
		$.each(log_arr, function(i, el){
			if($.inArray(el, unique_arr) === -1) {
				unique_arr.push(el);
			}
		});	
		
		for(var i = 0; i < unique_arr.length; i++){
			text += unique_arr[i] + ', ';
		}
		text = text.substring(0,text.lastIndexOf(","));
		if(text != ''){

			//data-toggle="tooltip" data-html="true" title="This is a regular Bootstrap tooltip<ul><li>item 1</li><li>item 2</li></ul>

			if(lt_header == 'Government Body'){
				$('.highlighter-data').append(`<div class="note note-primary m-b-15 card-2 animated fadeInUp" data-toggle="tooltip" data-placement="left" data-html="true" title="Tag if: <ul><li>Mere Mention of Government body found in KB</li></ul>">
						<div class="note-icon"><i class="fas fa-hotel"></i></div>
						<div class="note-content">
							<h4><b>`+lt_header+`</b></h4>
							<p>
								`+text+`
							</p>
						</div>
					</div>`);
			}
			else if (lt_header == 'Position'){
				$('.highlighter-data').append(`<div class="note note-danger m-b-15 card-2 animated fadeInUp" data-toggle="tooltip" data-placement="left" data-html="true" title="Tag if: <ul><li>Position found in KB (Except inclusive position)</li></ul>">
						<div class="note-icon"><i class="fas fa-user-tie"></i></div>
						<div class="note-content">
							<h4><b>`+lt_header+`</b></h4>
							<p>
								`+text+`
							</p>
						</div>
					</div>`);
			}
		
			
		} else {
			//$('.tagging-tree-logs').append('<p class="log-text">No match found.</p>');
		}
	
		
		
	}
	
	function resetHighlight(){

		console.log('Reset');

		$('body').unhighlight({ element: 'p', className: 'gov-body' });
		$('body').unhighlight({ element: 'p', className: 'position' });
		$('body').unhighlight({ element: 'p', className: 'election' });
		$('body').unhighlight({ element: 'p', className: 'common' });

		$('.tagging-tree-logs').html('');

		kwordsArr = [];
		localStorage.setItem('govStorage', '');
		
		positionArr = [];
		localStorage.setItem('positionStorage', '');

		electionArr = [];
		localStorage.setItem('electionStorage', '');

		commonArr = [];
		localStorage.setItem('commonStorage', '');

		posTaggings = '';

	}
	
	function resetSrtElementHighlights(){
		$('.srt-element').unhighlight({ element: 'p', className: 'gov-body' });
		$('.srt-element').unhighlight({ element: 'p', className: 'position' });
		$('.srt-element').unhighlight({ element: 'p', className: 'election' });
		$('.srt-element').unhighlight({ element: 'p', className: 'common' });
	}

},
handleTextToSpeech = function(){

//var arrVoices = ['Microsoft Zira Desktop - English (United States)', 'Microsoft David Desktop - English (United States)'];

var arrVoices = [
	{
		shortName: 'Microsoft Zira (US)',
		fullName: 'Microsoft Zira Desktop - English (United States)'
	},
	{
		shortName: 'Microsoft David (US)',
		fullName: 'Microsoft David Desktop - English (United States)'
	}
];


for(var i = 0; i < arrVoices.length; i++){
	$('.select-voice').append('<option value="'+arrVoices[i].fullName+'">'+arrVoices[i].shortName+'</option>');
}

var rat, pit, vol, voice;
var pausere_status = false;


var rateSliderValue = document.getElementById('rate-text');
var rateSlider = document.getElementById("rate-slider");
        noUiSlider.create(rateSlider, {
            start: [1],
            connect: "lower",
            range: {
                min: 0,
                max: 10
            }
}),
rateSlider.noUiSlider.on("update", function(values, handle) {
   rat = rateSliderValue.innerHTML = values[handle];
});

var pitchSliderValue = document.getElementById('pitch-text');
var pitchSlider = document.getElementById("pitch-slider");
        noUiSlider.create(pitchSlider, {
            start: [1.3],
            connect: "lower",
            range: {
                min: 0,
                max: 2
            }
}),
pitchSlider.noUiSlider.on("update", function(values, handle) {
   pit = pitchSliderValue.innerHTML = values[handle];
});

var volumeSliderValue = document.getElementById('volume-text');
var volumeSlider = document.getElementById("volume-slider");
        noUiSlider.create(volumeSlider, {
            start: [1],
            connect: "lower",
            range: {
                min: 0,
                max: 1
            }
}),
volumeSlider.noUiSlider.on("update", function(values, handle) {
   vol = volumeSliderValue.innerHTML = values[handle];
});

$(document).on('change', '.select-voice', function(){

	voice = $(this).val();
	console.log(voice);

});


$(document).on('click', '.t-play', function(){

	speak('.j-compo-text', voice, rat, pit, vol);

});

$(document).on('click', '.t-pause-resume', function(){
	
	if(!pausere_status){
		pause();
		pausere_status = true;
	} 
	else if(pausere_status){
		resume();
		pausere_status = false;
	}

});

$(document).on('click', '.t-stop', function(){
	
	 $().articulate('stop');

});

$(document).on('click', '.m-save-settings', function(){

	localStorage.setItem('rate', rat);
	localStorage.setItem('pitch', pit);
	localStorage.setItem('volume', vol);

	console.log(voice +" | "+ rat +" | "+ pit +" | "+ vol);
	console.log('Settings Saved');

});


function speak(obj, voice, rat, pit, vol) {
  $(obj).articulate('setVoice','name',voice).articulate('rate', rat).articulate('pitch', pit).articulate('volume', vol).articulate('speak');
}

function pause() {
  $().articulate('pause');
}

function resume() {
  $().articulate('resume');
}

function stop() {
  $().articulate('stop');
}




},
handleTaggingTree = function(){

var currComp = localStorage.getItem('currentComponent');

	fetchComponentF();

	var jobId = '';
	var fetchId = '';
	var realTimeId = '';
	var currentId = '';
	var nextId = '';
	var sec = 0;
	var hasJob = false;

	var getComponent = null;
	var getRealComponent = null;

	function fetchComponentF(){
		var fetchIdTimer = setInterval(function(){

		fetchId = $('._3-90._c24 a span').attr('value');
		getComponent = $('._4bl7._3-9a span').eq(1).text();
		
		$('.queue-c').text('Waiting for queue.');		

		if(typeof fetchId != 'undefined' && getComponent != ''){

			if(getComponent.toLowerCase().indexOf('title') != -1){
				localStorage.setItem('currentComponent', 'title');
			}
			if(getComponent.toLowerCase().indexOf('body') != -1){
				localStorage.setItem('currentComponent', 'body');
				
			}
			if(getComponent.toLowerCase().indexOf('image') != -1){
				localStorage.setItem('currentComponent', 'image');
			}
			if(getComponent.toLowerCase().indexOf('video') != -1){
				localStorage.setItem('currentComponent', 'video');
			}
			if(getComponent.toLowerCase().indexOf('english ad') != -1){
				localStorage.setItem('currentComponent', 'english ad');
			}

			$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			hasJob = true;
			clearInterval(fetchIdTimer);
		
			realTimerFetchF();
		}

		}, 1000);
	}	

	function realTimerFetchF(){

		var realTimer = setInterval(function(){

			if(hasJob){
	
				realTimeId = $('._3-90._c24 a span').attr('value');

				getComponentS = $('._4bl7._3-9a span').eq(1).text().split(' ');
		
				getRealComponent = (getComponent == '' && typeof getComponent == 'undefined') ? getRealComponent = 'Waiting for queue.' : getRealComponent = getComponentS[5] + ' - ' + getComponentS[7] +' '+ getComponentS[8]; 
	
				$('.queue-c').text(getRealComponent);

				sec++;

				if(fetchId != realTimeId){

					sec = 0;
					clearInterval(realTimer);
					fetchComponentF();
	
				}
		
				//console.log(sec);
			}

		}, 1000);
	}

	$(document).on('click', '._42ft', function(){
		var pn = $(this).attr('data-tooltip-content');
		if(pn == 'Previous' || pn == 'Next' || pn == 'Reload current job'){
			tagStopper = 0;
			isSubmitClicked = 0;
		}
	});

	var isSubmitClicked = 0;
	var tagStopper = 0;

	$(document).on('click', '._6_fv._3qn7._6twl._2fyi._1a9e button', function(){
		isSubmitClicked++;
		//console.log(isSubmitClicked);
	});

	$(document).on('keydown', function(e){

	if(e.which == 13){
		isSubmitClicked++;
		tagStopper = 0;
		//console.log(isSubmitClicked);
	}
		
	if(e.which == 27){
		tagStopper = 0;
		isSubmitClicked = 0;
		//console.log('Stopper: ' + tagStopper);

		$('.tagging-tree-logs').html('');
		$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");
	}

	if(e.which == 37 || e.which == 39){
		tagStopper = 0;
		isSubmitClicked = 0;
		$('.tagging-tree-logs').html('');
		$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");
	}
		
	if(localStorage.getItem('taggingTreeKey') == 'key1'){
		if((e.which == 109 && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body')){
			
			

			if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				tbComponent();
			} else if(isSubmitClicked == 4){

				isSubmitClicked = 0;
				tagStopper = 0;

				tbComponent();

			} else {
				//console.log('Something went wrong!');
			}


		}

		if((e.which == 107 && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'image' || currComp == 'video')){

			if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				imComponent();
			} else if(isSubmitClicked == 4){

				isSubmitClicked = 0;
				tagStopper = 0;

				imComponent();

			} else {
				//console.log('Something went wrong!');
			}
			

		}
	}
	else if(localStorage.getItem('taggingTreeKey') == 'key2'){
		
		if(((e.which == 84 || e.which == 66) && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body')){
			
			tbStopper()

		}

		if(((e.which == 73 || e.which == 86 || e.which == 69) && localStorage.getItem('taggingTree') == 'enabled') && (localStorage.getItem('currentComponent') == 'image' || localStorage.getItem('currentComponent') == 'video' || localStorage.getItem('currentComponent') == 'english ad')){
			
			ivStopper();
		}
		

	}
	
	else if(localStorage.getItem('taggingTreeKey') == 'key3'){
		
		if(e.which == 107 && localStorage.getItem('taggingTree') == 'enabled'){

			if(localStorage.getItem('currentComponent') == 'title' || localStorage.getItem('currentComponent') == 'body'){
				tbStopper();
			}
			else if(localStorage.getItem('currentComponent') == 'image' || localStorage.getItem('currentComponent') == 'video'){
				ivStopper();
			}
			else if(localStorage.getItem('currentComponent') == 'english ad'){
				ivStopper();
			}
			

		}

	}

	function tbStopper(){
		if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				tbComponent();
			} else if(isSubmitClicked == 5){

				isSubmitClicked = 0;
				tagStopper = 0;

				tbComponent();
	
				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			} else {
				//console.log('Something went wrong!');
			}
	}

	function ivStopper(){
		if(tagStopper === 0){
				isSubmitClicked = 0;
				tagStopper = 0;
			}
			
			tagStopper++;
			//console.log('Stopper: ' + tagStopper);
		
			if(isSubmitClicked == 0 && tagStopper == 1){
				imComponent();
			} else if(isSubmitClicked == 5){

				isSubmitClicked = 0;
				tagStopper = 0;

				imComponent();

				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').html("<span class='tagging-log'>Waiting for user's action.</span>");

			} else {
				//console.log('Something went wrong!');
			}
	}

	});

	function tbComponent(){
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').html('');
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Government Body</span>');
			},500);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				jQuery('._6_fv._3qn7._6twl._2fyi._1a9e button').click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Figure or Position</span>');
			},600);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Election mention</span>');
			},700);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Party</span>');
			},800);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				jQuery('._6_fv._3qn7._6twl._2fyi._1a9e button').click();
				$('.tagging-tree-logs').append('<span class="tagging-log">No, No Endorsement, Fundraising and Vote for or against</span>');
			},900);
			setTimeout(function(){
				jQuery('._4k_2  ._6_fu._6_fr').last().click();
				$('.tagging-tree-logs').append('<span class="tagging-log">Waiting for confirmation.</span>');
			},1000);
	}

	function imComponent(){


		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').html('');
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Government Body Mention</span>');
		},500);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political figure or Public office position</span>');
		},600);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political figure in the image</span>');
		},700);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Election mention</span>');
		},800);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No Political Party</span>');
		},900);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No, Endorsement, Fundraising and Vote for or against</span>');
		},1000);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			jQuery('._6g3g ._3qn7._6twl._2fyi._1a9e button').click();
			$('.tagging-tree-logs').append('<span class="tagging-log">No, No, GOTV mention</span>');
		},1100);
		setTimeout(function(){
			jQuery('._4k_2  ._6_fu._6_fr').last().click();
			$('.tagging-tree-logs').append('<span class="tagging-log">Waiting for confirmation.</span>');
		},1200);
		
			
	}

	$(document).on('click', '.hotkey-icon', function(){

		$('.key1, .key2, .key3').css('color', '#1c1e21');
		$('.label-key1').text('KEY 1');
		$('.label-key2').text('KEY 2');
		$('.label-key3').text('KEY 3');
		$('.label-key1, .label-key2, .label-key3').css('background', '#4cd964');
		
		$(this).find('.key').css('color', '#00BCD4');

		if($(this).attr('data-hotkey') == 'key1'){
			localStorage.setItem('taggingTreeKey', 'key1');
		
			$('.key1').css('color', '#00BCD4');
			$('.label-key1').text('KEY 1 ON');
			$('.label-key1').css('background', '#F44336');

		} else if($(this).attr('data-hotkey') == 'key2'){
			localStorage.setItem('taggingTreeKey', 'key2');
			
			$('.key2').css('color', '#00BCD4');
			$('.label-key2').text('KEY 2 ON');
			$('.label-key2').css('background', '#F44336');

		} else if($(this).attr('data-hotkey') == 'key3'){
			localStorage.setItem('taggingTreeKey', 'key3');
			
			$('.key3').css('color', '#00BCD4');
			$('.label-key3').text('KEY 3 ON');
			$('.label-key3').css('background', '#F44336');

		}
		
		//console.log($(this).attr('data-hotkey'));
	
	});	

	
	var chkSwitcherCtr = 0;

	var chkSwitcher = setInterval(function(){
		
		chkSwitcherCtr++;
		//console.log(chkSwitcherCtr);

		

		if(chkSwitcherCtr <= 10){
			if(localStorage.getItem('taggingTree') == 'enabled'){
				$('#tagging-tree-c').attr('checked','checked')
			} else {
				$('#tagging-tree-c').prop('checked', false);
			}
		
			if(localStorage.getItem('taggingTreeKey') == 'key1'){
				$('.key1').css('color', '#00BCD4');
				$('.label-key1').text('KEY 1 ON');
				$('.label-key1').css('background', '#F44336');
			}
			else if(localStorage.getItem('taggingTreeKey') == 'key2'){
				$('.key2').css('color', '#00BCD4');
				$('.label-key2').text('KEY 2 ON');
				$('.label-key2').css('background', '#F44336');
			}
			else if(localStorage.getItem('taggingTreeKey') == 'key3'){
				$('.key3').css('color', '#00BCD4');
				$('.label-key3').text('KEY 3 ON');
				$('.label-key3').css('background', '#F44336');
			}
			
		} else {
			clearInterval(chkSwitcher);
		}
		

	},1000);

	$(document).on('click', '.tagging-tree-l', function(){
		
		if($('#tagging-tree-c').is(":checked")){
			localStorage.setItem('taggingTree', 'disabled');
		}else {
			localStorage.setItem('taggingTree', 'enabled');
		}
	});

},
handleIdleTimer = function(){

  	var audio_url = chrome.runtime.getURL('audio/bells.mp3');
  	var audio = new Audio(audio_url);
    
  	var timer = -1;
  	var timerStartIn = 6;
  	var idle = null;
    
  	$(document).on('mousemove', function(){
      
        audio.pause(); // Stop playing
        audio.currentTime = 0; // Reset time
        
        timer = -1;
        timerStartIn = 6;
        $('.timer').html('Reviewer is active');
        $('.timer-content i').removeClass('animated shake infinite');
        clearInterval(idle);
        $('.it-status').html('<span> <strong>Reviewer Status: </strong> <span class="active m-r-10">Active</span></span>')
      
        idle = setInterval(function(){
            timer++;
            timerStartIn--;
            $('.timer').html('Reviewer is active. <br> Idle starts in ' + timerStartIn + ' second/s');
            
            if(timer >= 5){
                $('.timer').html('You are idle for about <br> ' + secondsToHms(timer - 5) +'.');
                console.log(timer);
                audio.play();
                $('.timer-content i').addClass('animated shake infinite');
                $('.it-status').html('<span> <strong>Reviewer Status: </strong> <span class="idle m-r-10">Idle</span></span>');
                console.log('Idle');
            }
            
        }, 1000);
        
        
  });
  
  
  function secondsToHms(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor(d % 3600 / 60);
    var s = Math.floor(d % 3600 % 60);

    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay + sDisplay; 
}
    
},
handleFullScreenMode = function(){

/* Get the element you want displayed in fullscreen mode (a video in this example): */
var elem = document.documentElement;
var fullScreenStatus = false;

$(document).on('click', '.m-fullscreen', function(){
	

	if(!fullScreenStatus){
		$('.m-fullscreen i').removeClass('ion-md-expand').addClass('ion-md-contract');
		openFullscreen(elem);
		fullScreenStatus = true;
	}
	else {
		$('.m-fullscreen i').removeClass('ion-md-contract').addClass('ion-md-expand');
		closeFullscreen();
		fullScreenStatus = false;
	}
});

	/* When the openFullscreen() function is executed, open the video in fullscreen.
	Note that we must include prefixes for different browsers, as they don't support the requestFullscreen method yet */
	function openFullscreen() {
	  if (elem.requestFullscreen) {
	    elem.requestFullscreen();
	  } else if (elem.mozRequestFullScreen) { /* Firefox */
	    elem.mozRequestFullScreen();
	  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
	    elem.webkitRequestFullscreen();
	  } else if (elem.msRequestFullscreen) { /* IE/Edge */
	    elem.msRequestFullscreen();
	  }
	}

	function closeFullscreen() {
	  if (document.exitFullscreen) {
	    document.exitFullscreen();
	  } else if (document.mozCancelFullScreen) { /* Firefox */
	    document.mozCancelFullScreen();
	  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
	    document.webkitExitFullscreen();
	  } else if (document.msExitFullscreen) { /* IE/Edge */
	    document.msExitFullscreen();
	  }
	}

},
handleAppSettings = function(){

console.log('app settings ok!');

if(localStorage.getItem('taggingTree') == null){localStorage.setItem('taggingTree', 'enabled')}
if(localStorage.getItem('taggingTreeKey') == null){localStorage.setItem('taggingTreeKey', 'key3')}

console.log('Tagging Tree: ' + localStorage.getItem('taggingTree'));
console.log('Tagging Tree Key: ' + localStorage.getItem('taggingTreeKey'));

},
Main = function() {
    'use strict';

    return {
        init: function() {

	var d = Date.now();
	var appToken = 1591190664000;

	
	if(d <= appToken && localStorage.getItem('app') == 'enabled'){

		handleSrtGUI(),
		handleInterface(),
		handleHighlighterCore(),
		handleHighlighterExec(),
		//handleTextToSpeech(),
		handleTaggingTree(),
		//handleIdleTimer(),
		handleFullScreenMode(),
		handleAppSettings()

			
	} else{
		console.log('Something went wrong. Contact Saitama!');
	}
	
        }
    }
}();
Main.init();

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

function handle_mousedown(e){
    window.my_dragging = {};
    my_dragging.pageX0 = e.pageX;
    my_dragging.pageY0 = e.pageY;
    my_dragging.elem = this;
    my_dragging.offset0 = $(this).offset();
    function handle_dragging(e){
        var left = my_dragging.offset0.left + (e.pageX - my_dragging.pageX0);
        var top = my_dragging.offset0.top + (e.pageY - my_dragging.pageY0);
        $(my_dragging.elem)
        .offset({top: top, left: left});
    }
    function handle_mouseup(e){
        $('body')
        .off('mousemove', handle_dragging)
        .off('mouseup', handle_mouseup);
	console.log('asd');
    }
    $('body')
    .on('mouseup', handle_mouseup)
    .on('mousemove', handle_dragging);
}

$('._7_5a._3qn7._61-0._2fyh._1a9e').mousedown(handle_mousedown);
